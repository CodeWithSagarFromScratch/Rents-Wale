import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/signup_controller.dart';
import 'package:rent_wale_latest/Services/form_validation_services.dart';
import 'package:rent_wale_latest/Widgets/custom_button.dart';
import 'package:rent_wale_latest/Widgets/custom_textfield.dart';


class SignupView extends StatelessWidget {
  const SignupView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<SignupController>(
          init: SignupController(),
          builder: (controller) {
            return Stack(
              children: [
                Container(
                  alignment: Alignment.topCenter,
                  height: Get.height * 0.350,
                  width: Get.width,
                  decoration: const BoxDecoration(
                      color: ColorConstant.redAccent,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(24),
                          bottomLeft: Radius.circular(24))),
                  child: Padding(
                    padding: EdgeInsets.only(top: Get.height * 0.050),
                    child: Text(
                      "Create Your Account",
                      style:
                          TextStyleConstant.bold30(color: ColorConstant.white),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: Get.height * 0.120,
                        bottom: Get.height * 0.060,
                        left: screenWidthPadding,
                        right: screenWidthPadding),
                    child: Container(
                      padding: screenPadding,
                      height: Get.height,
                      width: Get.width,
                      decoration: BoxDecoration(
                          color: ColorConstant.lightGrey.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(28)),
                      child: Form(
                        key: controller.formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: Image.asset(
                                ImagePathConstant.logo,
                                height: Get.height * 0.080,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: Get.height * 0.040,
                                  bottom: Get.height * 0.006),
                              child: Text(
                                "Enter Phone",
                                style: TextStyleConstant.semiBold16(),
                              ),
                            ),
                            CustomTextField(
                              controller: controller.phoneController,
                              hintText: "Phone",
                              textInputType: TextInputType.phone,
                              prefixIcon: const Icon(Icons.phone),
                              validator: FormValidationServices.validatePhone(),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: Get.height * 0.020,
                                  bottom: Get.height * 0.006),
                              child: Text(
                                "Enter Name",
                                style: TextStyleConstant.semiBold16(),
                              ),
                            ),
                            CustomTextField(
                              controller: controller.nameController,
                              hintText: "Name",
                              textInputType: TextInputType.name,
                              prefixIcon: const Icon(Icons.person),
                              validator: FormValidationServices.validateField(
                                  fieldName: "Name"),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: Get.height * 0.020,
                                  bottom: Get.height * 0.006),
                              child: Text(
                                "Enter Email",
                                style: TextStyleConstant.semiBold16(),
                              ),
                            ),
                            CustomTextField(
                              controller: controller.emailController,
                              hintText: "Email",
                              textInputType: TextInputType.emailAddress,
                              prefixIcon: const Icon(Icons.email),
                              validator: FormValidationServices.validateEmail(),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: Get.height * 0.020,
                                  bottom: Get.height * 0.006),
                              child: Text(
                                "Enter Password",
                                style: TextStyleConstant.semiBold16(),
                              ),
                            ),
                            CustomTextField(
                              controller: controller.passwordController,
                              hintText: "Password",
                              textInputType: TextInputType.visiblePassword,
                              prefixIcon: const Icon(Icons.lock),
                              validator: FormValidationServices.validateField(
                                  fieldName: "Password"),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: Get.height * 0.020,
                                  bottom: Get.height * 0.006),
                              child: Text(
                                "Select Type",
                                style: TextStyleConstant.semiBold16(),
                              ),
                            ),
                            CustomTextField(
                              controller: controller.selectTypeController,
                              hintText: "Select Type",
                              textInputType: TextInputType.text,
                              prefixIcon: const Icon(Icons.more),
                              validator: FormValidationServices.validateField(
                                  fieldName: "Type"),
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: Get.height * 0.040),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text("Already have an account  ",
                                      style: TextStyleConstant.medium16()),
                                  GestureDetector(
                                    onTap: () => Get.back(),
                                    child: Text("Login",
                                        style: TextStyleConstant.semiBold18(
                                            color: ColorConstant.redAccent)),
                                  ),
                                ],
                              ),
                            ),
                            const Spacer(),
                            Align(
                              alignment: Alignment.center,
                              child: CustomButton(
                                title: "Sign Up",
                                onTap: () {
                                  if (controller.formKey.currentState!
                                      .validate()) {
                                    controller.postSignup();
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          }),
    );
  }
}
