import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'Dashboard_Section/Product_Section/product_details_viewAPI.dart';

class Product {
  final String itemName;
  final String price;
  final String itemImg;
  final String itemMasterId;

  Product({
    required this.itemName,
    required this.price,
    required this.itemImg,
    required this.itemMasterId,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      itemName: json['item_name'],
      price: json['price_month'],
      itemImg: 'https://rentswale.com/admin/uploads/item/${json['item_img']}',
      itemMasterId: json['item_master_id'],
    );
  }
}

class TredingItemsListScreen extends StatefulWidget {
  @override
  _TredingItemsListScreenState createState() => _TredingItemsListScreenState();
}

class _TredingItemsListScreenState extends State<TredingItemsListScreen> {
  late List<Product> products = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {

    final response = await http.post(
      Uri.parse('https://rentswale.com/api/product_home.php'),
      body: {'city_name': 'pune'},
    );
  // Future<void> fetchData() async {
  //   String cityName = await StorageServices.getData(
  //       dataType: StorageKeyConstant.stringType,
  //       prefKey: StorageKeyConstant.cityName);
  //
  //   final response = await http.post(
  //     Uri.parse('https://rentswale.com/api/product_home.php'),
  //     body: {'city_name': cityName},
  //   );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);
      if (jsonData['status_code'] == '200') {
        List<Product> productList = [];
        for (var item in jsonData['product_list']) {
          productList.add(Product.fromJson(item));
        }
        setState(() {
          products = productList;
        });
      } else {
        print('Error: ${jsonData['message']}');
      }
    } else {
      print('Failed to load data');
    }
  }

  void navigateToProductDetails(String itemMasterId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NewProductDetails(itemMasterId: itemMasterId),
      //  builder: (context) => ProductDetailView(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: products.isEmpty
          ? const Center(child: Text('No products available'))
          : SizedBox(
        height: double.infinity,
      //  height: double.infinity,
        child: ListView.builder(
          physics: const BouncingScrollPhysics(),
          scrollDirection: Axis.horizontal,
          itemCount: products.length,
          itemBuilder: (context, index) {
            final product = products[index];
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: GestureDetector(
                onTap: () {
                  navigateToProductDetails(product.itemMasterId);
                },
                child: Container(
                  width: 190,
                  decoration: BoxDecoration(
                    color: Colors.redAccent[100],
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.network(
                            product.itemImg,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: double.infinity,


                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              product.itemName,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text('Price: ${product.price}'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

