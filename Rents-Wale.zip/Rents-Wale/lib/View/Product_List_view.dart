import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Dashboard_Section/Product_Section/product_details_viewAPI.dart';


class Product {
  final String itemName;
  final String price;
  final String description;
  final String itemImg;
  final String itemmasterid;

  Product({
    required this.itemName,
    required this.price,
    required this.description,
    required this.itemImg,
    required this.itemmasterid,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      itemName: json['item_name'],
      price: json['price_month'],
      description: json['description'],
      itemImg: 'http://rentswale.com/admin/uploads/item/${json['item_img']}',
      itemmasterid: json['item_master_id'],
    );
  }
}

class ProductListScreen extends StatefulWidget {
  final String categoryId;
  final String subcategoryId;

  ProductListScreen(this.categoryId, this.subcategoryId);

  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  late List<Product> products = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    // String cityName = await StorageServices.getData(
    //     dataType: StorageKeyConstant.stringType,
    //     prefKey: StorageKeyConstant.cityName);

    final response = await http.post(
      Uri.parse('https://rentswale.com/api/product_list.php'),
      body: {
        'category_id': widget.categoryId,
        'subcategory_id': widget.subcategoryId,
        'city_name': 'pune',
       //     'city_name': cityName,
      },
    );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);
      if (jsonData['status_code'] == '200') {
        List<Product> productList = [];
        for (var item in jsonData['product_list']) {
          productList.add(Product.fromJson(item));
        }
        setState(() {
          products = productList;
        });
      } else {
        print('Error: ${jsonData['message']}');
      }
    } else {
      print('Failed to load data');
    }
  }

  void navigateToProductDetails(String itemMasterId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NewProductDetails(itemMasterId: itemMasterId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product List'),
      ),
      body: products.isEmpty
          ? Center(
        child: CircularProgressIndicator(),
      )
          : ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                  onTap: () {
                    navigateToProductDetails(product.itemmasterid);
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Product Image with Price Tag
                      Container(
                        width: 150,
                        height: 150,
                        child: Stack(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Container(
                                decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 2,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Image.network(
                                  product.itemImg,
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                  height: double.infinity,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              left: 0,
                              right: 0,
                              child: Container(
                                color: Colors.black.withOpacity(0.7),
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                child: Text(
                                  'Price: ${product.price}',
                                  style: TextStyle(color: Colors.white, fontSize: 18),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 15),
                      // Product Name and Description
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 25, left: 10),
                              child: Text(
                                product.itemName,
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                            SizedBox(height: 4),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text("Galaxy Apartment Housing"),
                            ),
                            // SizedBox(height: 4),
                            // Padding(
                            //   padding: const EdgeInsets.all(8.0),
                            //   child: Text(product.description),
                            // ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Divider(
                height: 20,
                color: Colors.grey[400],
                thickness: 1.0,
              ),
            ],
          );
        },
      ),
    );
  }
}
