import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/dashboard_controller.dart';
import 'package:rent_wale_latest/View/Treding_ItemList_ViewApi.dart';
import 'package:rent_wale_latest/Widgets/custom_no_data_found.dart';
import 'MenuBar_ItemList_View.dart';
import 'Product_Section/product_details_viewAPI.dart';
import 'choose_location_view.dart';
import 'categoty_viewapi_.dart';

class DashboardView extends StatefulWidget {
  const DashboardView({Key? key}) : super(key: key);

  @override
  State<DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<DashboardView> {
  String selectedCity = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(

        child: Container(
          width: MediaQuery.of(context).size.width * 0.100, // Adjust the width as needed (e.g., 80% of screen width)
          child: MenuBarItemList(),
        ),
      ),
      body: GetBuilder<DashboardController>(
        init: DashboardController(),
        builder: (controller) {
          return SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: Get.height * 0.370,
                  width: Get.width,
                  decoration: BoxDecoration(
                    color: ColorConstant.redAccent,
                    borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(24),
                      bottomLeft: Radius.circular(24),
                    ),
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                          top: Get.height * 0.060,
                          left: screenWidthPadding,
                          right: screenWidthPadding,
                        ),
                        child: Row(
                          children: [
                            Container(
                              alignment: Alignment.center,
                              height: Get.height * 0.057,
                              width: Get.width * 0.121,
                              decoration: BoxDecoration(
                                color: ColorConstant.white,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Builder(
                                // Wrap the IconButton with Builder to get the correct context
                                builder: (context) => IconButton(
                                  icon: Icon(Icons.menu),
                                  onPressed: () {
                                    // Open the drawer when menu icon is clicked
                                    Scaffold.of(context).openDrawer();
                                  },
                                ),
                              ),
                            ),
                            Image.asset(
                              ImagePathConstant.logo1,
                              height: Get.height * 0.060,
                              width: Get.width * 0.486,
                            ),
                            // Add other widgets as needed
                            SingleChildScrollView(
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: GestureDetector(
                                    child: GestureDetector(
                                      onTap: () async {
                                        final result = await Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                              const ChooseLocationView()),
                                        );
                                        setState(() {
                                          // Update the selected city name when it's returned from the next page
                                          selectedCity = result ?? '';
                                        });
                                      },
                                      child: Container(
                                        padding: contentPadding,
                                        height: Get.height * 0.057,
                                        width: Get.width * 0.262,
                                        decoration: BoxDecoration(
                                          color: ColorConstant.white,
                                          borderRadius: BorderRadius.circular(16),
                                        ),
                                        child: Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                selectedCity,
                                                style: TextStyleConstant.semiBold18(
                                                  color: ColorConstant.darkGrey,
                                                ),
                                              ),
                                              const Icon(
                                                Icons.pin_drop,
                                                color: ColorConstant.darkGrey,
                                              )
                                            ]),
                                      ),
                                    ),
                                  ),
                                )
                            )
                          ],
                        ),
                      ),
                      // Add other widgets as needed
                      SizedBox(
                        height: Get.height * 0.150,
                        width: Get.width,
                        child: (controller.getBannerImagesModel.sliderList != null)
                            ? CarouselSlider.builder(
                          itemCount: controller
                              .getBannerImagesModel.sliderList?.length,
                          itemBuilder: (context, index, realIndex) {
                            return Container(
                              width: Get.width * 0.900,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                image: DecorationImage(
                                  image: NetworkImage(
                                      "${controller.getBannerImagesModel.sliderList?[index].bannerImage}"),
                                  fit: BoxFit.fill,
                                ),
                              ),
                            );
                          },
                          options: CarouselOptions(
                            initialPage: 0,
                            autoPlay: true,
                            height: Get.height * 0.160,
                            viewportFraction: 1,
                          ),
                        )
                            : const CustomNoDataFound(),
                      ),
                      SizedBox(height: 12,),
                      Padding(
                        padding: screenHorizontalPadding,
                        child: Container(
                          height: 40,
                          child: SearchBar(
                            hintText: "Search Your Items",
                            trailing: [
                              Padding(
                                padding: EdgeInsets.only(
                                  right: contentWidthPadding,
                                ),
                                child: const Icon(Icons.search_rounded),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 350, width: 420, child: CategoryListPage()),
                Padding(
                  padding: screenPadding,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Trending Items",
                        style: TextStyleConstant.semiBold18(),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                          vertical: Get.height * 0.010,
                          horizontal: Get.width * 0.014,
                        ),
                        decoration: BoxDecoration(
                          color: ColorConstant.lightGrey,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(
                                right: Get.width * 0.016,
                              ),
                              child: Image.asset(
                                ImagePathConstant.more,
                                height: Get.height * 0.012,
                              ),
                            ),
                            Text(
                              "View All Items",
                              style: TextStyleConstant.medium12(),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.260,
                  child: ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemCount: 1, // Show only one item
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: contentHorizontalPadding,
                        child: GestureDetector(
                          onTap: () => Get.to(() => const NewProductDetails(
                            itemMasterId: '',
                          )),
                          // Navigate to ProductDetailView
                          child: Container(
                            height: 500,
                            width: 400,
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: TredingItemsListScreen(),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(
                  height: Get.height * 0.220,
                  width: Get.width,
                  child: (controller.getOfferImagesModel.offerlist != null)
                      ? CarouselSlider.builder(
                    itemCount:
                    controller.getOfferImagesModel.offerlist?.length,
                    itemBuilder: (context, index, realIndex) {
                      return Container(
                        width: Get.width * 0.900,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          image: DecorationImage(
                            image: NetworkImage(
                                "${controller.getOfferImagesModel.offerlist?[index].sliderimage}"),
                            fit: BoxFit.fill,
                          ),
                        ),
                      );
                    },
                    options: CarouselOptions(
                      initialPage: 0,
                      autoPlay: true,
                      height: Get.height * 0.170,
                      viewportFraction: 1,
                    ),
                  )
                      : const CustomNoDataFound(),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

