import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/post_product_controller.dart';
import 'package:rent_wale_latest/Services/form_validation_services.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/enter_address_view.dart';
import 'package:rent_wale_latest/Widgets/custom_button.dart';
import 'package:rent_wale_latest/Widgets/custom_textfield.dart';
import 'package:rent_wale_latest/Widgets/custom_toast.dart';

class PostProductView extends StatefulWidget {
  const PostProductView({super.key});

  @override
  State<PostProductView> createState() => _PostProductViewState();
}

class _PostProductViewState extends State<PostProductView> {
  PostProductController controller = Get.put(PostProductController());

  @override
  void initState() {
    super.initState();
    controller.getCategoryList().whenComplete(() => setState(() {}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          Container(
            alignment: Alignment.topCenter,
            height: Get.height * 0.350,
            width: Get.width,
            decoration: const BoxDecoration(
                color: ColorConstant.redAccent,
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(24),
                    bottomLeft: Radius.circular(24))),
            child: Padding(
              padding: EdgeInsets.only(top: Get.height * 0.050),
              child: Text(
                "Post Your Product",
                style: TextStyleConstant.bold30(color: ColorConstant.white),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(
                  top: Get.height * 0.120,
                  bottom: Get.height * 0.060,
                  left: screenWidthPadding,
                  right: screenWidthPadding),
              child: Container(
                padding: screenPadding,
                height: Get.height,
                width: Get.width,
                decoration: BoxDecoration(
                    color: ColorConstant.lightGrey.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(28)),
                child: Form(
                  key: controller.formKey,
                  child: ListView(
                    children: [
                      Text(
                        "Choose Your Category",
                        style: TextStyleConstant.semiBold16(),
                      ),
                      Card(
                        child: ListTile(
                          onTap: () {
                            Get.dialog(
                              Material(
                                child: Container(
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      color: ColorConstant.white,
                                      borderRadius: BorderRadius.circular(16)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          IconButton(
                                              onPressed: () => Get.back(),
                                              icon:
                                                  const Icon(Icons.arrow_back)),
                                          Text(
                                            "Select Category",
                                            style:
                                                TextStyleConstant.semiBold22(),
                                          ),
                                        ],
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: Get.width * 0.038),
                                          child: ListView.builder(
                                            physics:
                                                const BouncingScrollPhysics(),
                                            itemCount: controller
                                                .getCategoryListModel
                                                .categoryList
                                                ?.length,
                                            itemBuilder: (context, index) {
                                              return Card(
                                                child: ListTile(
                                                    onTap: () async {
                                                      controller
                                                              .selectedCategory
                                                              .value =
                                                          "${controller.getCategoryListModel.categoryList?[index].categoryMaster}";
                                                      controller
                                                              .selectedCategoryId
                                                              .value =
                                                          "${controller.getCategoryListModel.categoryList?[index].categoryId}";
                                                      await controller
                                                          .getSubCategoryList();
                                                      controller.update();
                                                      Get.back();
                                                    },
                                                    title: Text(
                                                        "${controller.getCategoryListModel.categoryList?[index].categoryMaster}")),
                                              );
                                            },
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                          title: Obx(() {
                            return Text(controller.selectedCategory.value);
                          }),
                          trailing: const Icon(Icons.arrow_drop_down),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            bottom: Get.height * 0.006,
                            top: Get.height * 0.020),
                        child: Text(
                          "Choose Your Subcategory",
                          style: TextStyleConstant.semiBold16(),
                        ),
                      ),
                      Card(
                        child: ListTile(
                          onTap: () {
                            if (controller
                                    .getSubCategoryModel.subcategoryList !=
                                null) {
                              Get.dialog(
                                Material(
                                  child: Container(
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                        color: ColorConstant.white,
                                        borderRadius:
                                            BorderRadius.circular(16)),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            IconButton(
                                                onPressed: () => Get.back(),
                                                icon: const Icon(
                                                    Icons.arrow_back)),
                                            Text(
                                              "Select Subcategory",
                                              style: TextStyleConstant
                                                  .semiBold22(),
                                            ),
                                          ],
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: Get.width * 0.038),
                                            child: ListView.builder(
                                              physics:
                                                  const BouncingScrollPhysics(),
                                              itemCount: controller
                                                  .getSubCategoryModel
                                                  .subcategoryList
                                                  ?.length,
                                              itemBuilder: (context, index) {
                                                return Card(
                                                  child: ListTile(
                                                      onTap: () {
                                                        controller
                                                                .selectedSubCategory
                                                                .value =
                                                            "${controller.getSubCategoryModel.subcategoryList?[index].subCategory}";
                                                        controller
                                                                .selectedSubCategoryId
                                                                .value =
                                                            "${controller.getSubCategoryModel.subcategoryList?[index].subCategoryId}";
                                                        controller.update();
                                                        Get.back();
                                                      },
                                                      title: Text(
                                                          "${controller.getSubCategoryModel.subcategoryList?[index].subCategory}")),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            } else {
                              customToast(message: "Please Select Category");
                            }
                          },
                          title: Obx(() {
                            return Text(controller.selectedSubCategory.value);
                          }),
                          trailing: const Icon(Icons.arrow_drop_down),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: Get.height * 0.020),
                        child: Text(
                          "Select Tenure",
                          style: TextStyleConstant.semiBold16(),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: Get.height * 0.006,
                            bottom: Get.height * 0.020),
                        child: Card(
                          child: ListTile(
                            onTap: () {
                              Get.dialog(
                                Material(
                                  child: Container(
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                        color: ColorConstant.white,
                                        borderRadius:
                                            BorderRadius.circular(16)),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            IconButton(
                                                onPressed: () => Get.back(),
                                                icon: const Icon(
                                                    Icons.arrow_back)),
                                            Text(
                                              "Select Tenure",
                                              style: TextStyleConstant
                                                  .semiBold22(),
                                            ),
                                          ],
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: Get.width * 0.038),
                                            child: ListView.builder(
                                              physics:
                                                  const BouncingScrollPhysics(),
                                              itemCount:
                                                  controller.tenureList.length,
                                              itemBuilder: (context, index) {
                                                return Card(
                                                  child: ListTile(
                                                      onTap: () {
                                                        controller
                                                                .selectedTenure
                                                                .value =
                                                            "${controller.tenureList[index]}";
                                                        controller.update();
                                                        Get.back();
                                                      },
                                                      title: Text(
                                                          "${controller.tenureList[index]}")),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                            title: Obx(() {
                              return Text(controller.selectedTenure.value);
                            }),
                            trailing: const Icon(Icons.arrow_drop_down),
                          ),
                        ),
                      ),
                      Text(
                        "Enter Your Price",
                        style: TextStyleConstant.semiBold16(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: Get.height * 0.006,
                            bottom: Get.height * 0.020),
                        child: CustomTextField(
                          controller: controller.priceController,
                          hintText: "Enter Your Price",
                          textInputType: TextInputType.name,
                          prefixIcon: const Icon(Icons.currency_rupee),
                          validator: FormValidationServices.validateField(
                              fieldName: "Price"),
                        ),
                      ),
                      Text(
                        "Enter Your Product Name",
                        style: TextStyleConstant.semiBold16(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: Get.height * 0.006,
                            bottom: Get.height * 0.020),
                        child: CustomTextField(
                          controller: controller.nameController,
                          hintText: "Enter Product Name",
                          textInputType: TextInputType.name,
                          prefixIcon:
                              const Icon(Icons.drive_file_rename_outline),
                          validator: FormValidationServices.validateField(
                              fieldName: "Product Name"),
                        ),
                      ),
                      Text(
                        "Enter Description",
                        style: TextStyleConstant.semiBold16(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: Get.height * 0.006,
                            bottom: Get.height * 0.020),
                        child: CustomTextField(
                          controller: controller.descriptionController,
                          hintText: "Enter Description",
                          textInputType: TextInputType.name,
                          validator: FormValidationServices.validateField(
                              fieldName: "Description"),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: CustomButton(
                          title: "Next Page",
                          onTap: () {
                            if (controller.formKey.currentState!.validate()) {
                              if (controller.selectedCategory.value !=
                                  "Select Category") {
                                if (controller.selectedSubCategory.value !=
                                    "Select Subcategory") {
                                  if (controller.selectedTenure.value !=
                                      "Select Tenure") {
                                    controller.postProductCategory();
                                  } else {
                                    customToast(
                                        message: "Please Select Tenure");
                                  }
                                } else {
                                  customToast(message: "Select Subcategory");
                                }
                              } else {
                                customToast(message: "Please Select Category");
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
