import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/enter_address_controller.dart';
import 'package:rent_wale_latest/Services/form_validation_services.dart';
import 'package:rent_wale_latest/Widgets/custom_button.dart';
import 'package:rent_wale_latest/Widgets/custom_textfield.dart';
import 'package:rent_wale_latest/Widgets/custom_toast.dart';

class EnterAddressView extends StatefulWidget {
  final String itemId;
  final String address;
  final String pinCode;
  final String state;
  final String city;
  final String subLocality;

  const EnterAddressView(
      {super.key,
      required this.itemId,
      required this.address,
      required this.pinCode,
      required this.state,
      required this.city,
      required this.subLocality});

  @override
  State<EnterAddressView> createState() => _EnterAddressViewState();
}

class _EnterAddressViewState extends State<EnterAddressView> {
  EnterAddressController controller = Get.put(EnterAddressController());

  @override
  void initState() {
    super.initState();
    initialFunctioun().whenComplete(() => setState(() {}));
  }

  Future initialFunctioun() async {
    controller.pinCodeController.text = widget.pinCode;
    controller.locationController.text = widget.address;
    controller.stateController.text = widget.state;
    controller.cityNameController.text = widget.city;
    controller.localityNameController.text = widget.subLocality;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Container(
            alignment: Alignment.topCenter,
            height: Get.height * 0.350,
            width: Get.width,
            decoration: const BoxDecoration(
                color: ColorConstant.redAccent,
                borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(24),
                    bottomLeft: Radius.circular(24))),
            child: Padding(
              padding: EdgeInsets.only(top: Get.height * 0.050),
              child: Text(
                "Enter Your Address",
                style: TextStyleConstant.bold30(color: ColorConstant.white),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(
                  top: Get.height * 0.120,
                  bottom: Get.height * 0.060,
                  left: screenWidthPadding,
                  right: screenWidthPadding),
              child: Container(
                padding: screenPadding,
                height: Get.height,
                width: Get.width,
                decoration: BoxDecoration(
                    color: ColorConstant.lightGrey.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(28)),
                child: Form(
                  key: controller.formKey,
                  child: ListView(
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Get Your Current Location",
                        style: TextStyleConstant.semiBold16(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: Get.height * 0.006,
                            bottom: Get.height * 0.020),
                        child: CustomTextField(
                          controller: controller.locationController,
                          hintText: "Enter Your Current Location",
                          textInputType: TextInputType.name,
                          suffixIcon: const Icon(Icons.pin_drop),
                          validator: FormValidationServices.validateField(
                              fieldName: "Location"),
                        ),
                      ),
                      Text(
                        "Enter Your PinCode",
                        style: TextStyleConstant.semiBold16(),
                      ),
                      Padding(
                          padding: EdgeInsets.only(
                              top: Get.height * 0.006,
                              bottom: Get.height * 0.020),
                          child: CustomTextField(
                              controller: controller.pinCodeController,
                              hintText: "Enter Your PinCode",
                              textInputType: TextInputType.number,
                              suffixIcon: const Icon(Icons.pin),
                              validator: FormValidationServices.validateField(
                                  fieldName: "PinCode"))),
                      Text("Enter Your State Name",
                          style: TextStyleConstant.semiBold16()),
                      Padding(
                          padding: EdgeInsets.only(
                              top: Get.height * 0.006,
                              bottom: Get.height * 0.020),
                          child: CustomTextField(
                              controller: controller.stateController,
                              hintText: "Enter Your State Name",
                              textInputType: TextInputType.name,
                              suffixIcon: const Icon(Icons.location_city),
                              validator: FormValidationServices.validateField(
                                  fieldName: "City Name"))),
                      Text("Enter Your City Name",
                          style: TextStyleConstant.semiBold16()),
                      Padding(
                          padding: EdgeInsets.only(
                              top: Get.height * 0.006,
                              bottom: Get.height * 0.020),
                          child: CustomTextField(
                              controller: controller.cityNameController,
                              hintText: "Enter Your City Name",
                              textInputType: TextInputType.name,
                              suffixIcon: const Icon(Icons.location_city),
                              validator: FormValidationServices.validateField(
                                  fieldName: "City Name"))),
                      Text(
                        "Enter Your Locality",
                        style: TextStyleConstant.semiBold16(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: Get.height * 0.006,
                            bottom: Get.height * 0.020),
                        child: CustomTextField(
                          controller: controller.localityNameController,
                          hintText: "Enter Your Locality",
                          textInputType: TextInputType.name,
                          suffixIcon: const Icon(Icons.pin),
                          validator: FormValidationServices.validateField(
                              fieldName: "Locality"),
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "Enter Your Products Image",
                          style: TextStyleConstant.semiBold16(),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: Get.height * 0.030),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            imageBox(
                                onTap: () {
                                  selectImageSourceDialog(
                                      controller: controller, imageNo: 1);
                                },
                                image: (controller.selectedImage1 != null)
                                    ? File(controller.selectedImage1!.path)
                                    : File("")),
                            imageBox(
                                onTap: () {
                                  selectImageSourceDialog(
                                      controller: controller, imageNo: 2);
                                },
                                image: (controller.selectedImage2 != null)
                                    ? File(controller.selectedImage2!.path)
                                    : File("")),
                            imageBox(
                                onTap: () {
                                  selectImageSourceDialog(
                                      controller: controller, imageNo: 3);
                                },
                                image: (controller.selectedImage3 != null)
                                    ? File(controller.selectedImage3!.path)
                                    : File("")),
                            imageBox(
                                onTap: () {
                                  selectImageSourceDialog(
                                      controller: controller, imageNo: 4);
                                },
                                image: (controller.selectedImage4 != null)
                                    ? File(controller.selectedImage4!.path)
                                    : File("")),
                          ],
                        ),
                      ),
                      SizedBox(height: Get.height * 0.050),
                      Align(
                        alignment: Alignment.center,
                        child: CustomButton(
                          title: "Next Page",
                          onTap: () {
                            if (controller.formKey.currentState!.validate()) {
                              if (controller.selectedImage1 != null &&
                                  controller.selectedImage2 != null &&
                                  controller.selectedImage3 != null &&
                                  controller.selectedImage4 != null) {
                                controller.postAddress(itemId: widget.itemId);
                              } else {
                                customToast(message: "Please Select Images");
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  selectImageSourceDialog(
      {required EnterAddressController controller, required int imageNo}) {
    return Get.dialog(AlertDialog(
      title: const Text("Select Image Source Type"),
      content: Column(
        children: [
          Card(
              child: ListTile(
            onTap: () {
              Get.back();
              controller
                  .pickImage(imageNo: imageNo, imageSource: ImageSource.camera)
                  .whenComplete(() => controller.update());
            },
            title: const Text("Select From Camera"),
          )),
          Card(
              child: ListTile(
            onTap: () {
              Get.back();
              controller
                  .pickImage(imageNo: imageNo, imageSource: ImageSource.gallery)
                  .whenComplete(() => controller.update());
            },
            title: const Text("Select From Gallery"),
          )),
        ],
      ),
    ));
  }

  Widget imageBox({required Function() onTap, required File image}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: Get.height * 0.080,
        width: Get.width * 0.170,
        decoration: BoxDecoration(
            color: ColorConstant.lightGrey,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(width: 2, color: ColorConstant.darkGrey),
            image: DecorationImage(image: FileImage(image), fit: BoxFit.fill)),
      ),
    );
  }
}
