import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'dart:convert';

import 'package:rent_wale_latest/Constant/layout_constant.dart';

class SliderImage {
  final String slideId;
  final String sliderImage;

  SliderImage({required this.slideId, required this.sliderImage});

  factory SliderImage.fromJson(Map<String, dynamic> json) {
    return SliderImage(
      slideId: json['slide_id'],
      sliderImage: json['slider_image'],
    );
  }
}

class SliderApiPage extends StatefulWidget {
  @override
  _SliderApiPageState createState() => _SliderApiPageState();
}

class _SliderApiPageState extends State<SliderApiPage> {
  List<SliderImage> _sliderImages = [];
  bool _isLoading = true;

  Future<void> _fetchSliderImages() async {
    final response = await http.get(Uri.parse('https://rentswale.com/api/slider.php'));
    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      setState(() {
        _sliderImages = (jsonData['slider_list'] as List)
            .map((item) => SliderImage.fromJson(item))
            .toList();
        _isLoading = false;
      });
    } else {
      throw Exception('Failed to load slider images');
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchSliderImages();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : CarouselSlider.builder(
        itemCount: _sliderImages.length,
        itemBuilder: (context, index, realIndex) {
          final imageUrl = 'https://rentswale.com/admin/uploads/${_sliderImages[index].sliderImage}';
          return Padding(
            padding: contentPadding,
            child: Container(
              height: Get.height * 0.200, // Adjust the height as needed
              width: Get.width, // Adjust the width as needed
              decoration: BoxDecoration(
                color: ColorConstant.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Image.network(
                imageUrl,
                fit: BoxFit.cover, // Ensure the image covers the container
              ),
            ),
          );
        },
        options: CarouselOptions(
          initialPage: 0,
          autoPlay: true,
          height: Get.height * 0.150,
          viewportFraction: 1,
        ),
      ),
    );
  }
}




