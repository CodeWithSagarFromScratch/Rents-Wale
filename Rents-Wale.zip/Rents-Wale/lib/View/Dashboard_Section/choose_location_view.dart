import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/dashboard_controller.dart';
import 'package:rent_wale_latest/Widgets/custom_button.dart';
import 'package:rent_wale_latest/Models/ChooseLocation_model.dart'; // Import your model

class ChooseLocationView extends StatelessWidget {
  const ChooseLocationView({Key? key});

  @override
  Widget build(BuildContext context) {
    // final ChooeseLocationmodel controller = Get.find(); // Instantiate your controller

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<DashboardController>(
        init: DashboardController(),
        builder: (controller) {
          return SingleChildScrollView(
            child: Stack(
              children: [
                Container(
                  alignment: Alignment.topCenter,
                  height: Get.height * 0.350,
                  width: Get.width,
                  decoration: BoxDecoration(
                    color: ColorConstant.redAccent,
                    borderRadius: const BorderRadius.only(
                      bottomRight: Radius.circular(24),
                      bottomLeft: Radius.circular(24),
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(top: Get.height * 0.050),
                    child: Text(
                      "Choose Your Location",
                      style: TextStyleConstant.bold30(color: ColorConstant.white),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: EdgeInsets.only(
                      top: Get.height * 0.100,
                      bottom: Get.height * 0.020,
                      left: screenWidthPadding,
                      right: screenWidthPadding,
                    ),
                    child: Container(
                      padding: screenPadding,
                      height: Get.height,
                      width: Get.width,
                      decoration: BoxDecoration(
                        color: ColorConstant.lightGrey.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Image.asset(
                              ImagePathConstant.logo,
                              height: Get.height * 0.080,
                            ),
                          ),
                          SizedBox(
                            height: 100,
                            child: Padding(
                              padding: EdgeInsets.symmetric(vertical: Get.height * 0.020),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: ListView.builder(
                                      scrollDirection: Axis.horizontal,
                                      itemCount: controller.getChooeseLocationModel.cityList?.length ?? 0,
                                      itemBuilder: (context, index) {
                                        final CityList city = controller.getChooeseLocationModel.cityList![index];
                                        return GestureDetector(
                                          onTap: () {
                                            Navigator.pop(context, city.name); // Pass the selected city name back to the previous page
                                          },
                                          child: _buildContainer(city.name ?? ''),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Spacer(),
                          Align(
                            alignment: Alignment.center,
                            child: CustomButton(
                              title: "Set Automatically",
                              width: Get.width * 0.500,
                              onTap: () {},
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

Widget _buildContainer(String cityName) {
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 8.0),
    height: Get.height * 0.080,
    width: Get.width * 0.170,
    decoration: BoxDecoration(
     // color: ColorConstant.lightGrey,
      color: ColorConstant.white,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(
        width: 2,
        color: ColorConstant.darkGrey,
      ),
    ),
    child: Center(
      child: Text(
        cityName,
        style: TextStyleConstant.regular16(),
      ),
    ),
  );
}

