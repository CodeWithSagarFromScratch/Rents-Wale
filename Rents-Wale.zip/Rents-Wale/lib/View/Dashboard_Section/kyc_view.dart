import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/kyc_controller.dart';
import 'package:rent_wale_latest/Widgets/custom_textfield.dart';

import '../../Widgets/custom_button.dart';
import 'bottom_bar_view.dart';


class KycView extends StatelessWidget {
  const KycView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<KycController>(
          init: KycController(),
          builder: (controller) {
            return Stack(
              children: [
                Container(
                  alignment: Alignment.topCenter,
                  height: Get.height * 0.350,
                  width: Get.width,
                  decoration: const BoxDecoration(
                      color: ColorConstant.redAccent,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(24),
                          bottomLeft: Radius.circular(24))),
                  child: Padding(
                    padding: EdgeInsets.only(top: Get.height * 0.050),
                    child: Text(
                      "KYC",
                      style:
                          TextStyleConstant.bold30(color: ColorConstant.white),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: Get.height * 0.120,
                        bottom: Get.height * 0.060,
                        left: screenWidthPadding,
                        right: screenWidthPadding),
                    child: Container(
                      padding: screenPadding,
                      height: Get.height,
                      width: Get.width,
                      decoration: BoxDecoration(
                          color: ColorConstant.lightGrey.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(28)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Image.asset(
                              ImagePathConstant.logo,
                              height: Get.height * 0.080,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: Get.height * 0.060,
                                bottom: Get.height * 0.006),
                            child: Text(
                              "Enter Adhar Number",
                              style: TextStyleConstant.semiBold16(),
                            ),
                          ),
                          CustomTextField(
                            controller: controller.adharController,
                            hintText: "Adhar Number",
                            textInputType: TextInputType.text,
                            prefixIcon: const Icon(Icons.person),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: Get.height * 0.020,
                                bottom: Get.height * 0.006),
                            child: Text(
                              "Enter DI Number",
                              style: TextStyleConstant.semiBold16(),
                            ),
                          ),
                          CustomTextField(
                            controller: controller.diController,
                            hintText: "Di Number",
                            textInputType: TextInputType.text,
                            prefixIcon: const Icon(Icons.numbers),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: Get.height * 0.030),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  height: Get.height * 0.080,
                                  width: Get.width * 0.170,
                                  decoration: BoxDecoration(
                                      color: ColorConstant.lightGrey,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(
                                          width: 2,
                                          color: ColorConstant.darkGrey)),
                                ),
                                Container(
                                  height: Get.height * 0.080,
                                  width: Get.width * 0.170,
                                  decoration: BoxDecoration(
                                      color: ColorConstant.lightGrey,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(
                                          width: 2,
                                          color: ColorConstant.darkGrey)),
                                ),
                                Container(
                                  height: Get.height * 0.080,
                                  width: Get.width * 0.170,
                                  decoration: BoxDecoration(
                                      color: ColorConstant.lightGrey,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(
                                          width: 2,
                                          color: ColorConstant.darkGrey)),
                                ),
                                Container(
                                  height: Get.height * 0.080,
                                  width: Get.width * 0.170,
                                  decoration: BoxDecoration(
                                      color: ColorConstant.lightGrey,
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(
                                          width: 2,
                                          color: ColorConstant.darkGrey)),
                                ),
                              ],
                            ),
                          ),
                          const Spacer(),
                          Align(
                            alignment: Alignment.center,
                            child: CustomButton(
                              title: "Submit",
                              onTap: () => Get.offAll(() => BottomBarView()),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          }),
    );
  }
}
