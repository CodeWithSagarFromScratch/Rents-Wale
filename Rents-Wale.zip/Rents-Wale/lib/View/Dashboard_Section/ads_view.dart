import 'package:flutter/material.dart';

class AdsView extends StatelessWidget {
  const AdsView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
