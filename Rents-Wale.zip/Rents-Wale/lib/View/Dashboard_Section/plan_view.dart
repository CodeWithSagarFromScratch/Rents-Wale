import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Models/planView_model.dart';
import 'package:rent_wale_latest/Controllers/planView_controller.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/Widgets/custom_button.dart';

class PlanView extends StatefulWidget {
  const PlanView({Key? key}) : super(key: key);

  @override
  _PlanViewState createState() => _PlanViewState();
}

class _PlanViewState extends State<PlanView> {
  late PlanViewController planController;
  List<PackageList> packageList = [];
  String? selectedPlan;

  final List<Color> itemColors = [
    ColorConstant.extraLightGrey,
    ColorConstant.lightPurple,
    ColorConstant.yellow.withOpacity(0.5),
    ColorConstant.redAccent.withOpacity(0.5),
  ];

  @override
  void initState() {
    super.initState();
    planController = PlanViewController();
    fetchPlanData();
  }

  Future<void> fetchPlanData() async {
    try {
      await planController.getPlanViewList();
      setState(() {
        packageList = planController.getPlanViewModel.packagelist ?? [];
      });
    } catch (e) {
      print('Error fetching package data: $e');
      // Handle error appropriately (e.g., show error message to the user)
    }
  }

  Future<void> purchasePackage(PackageList package) async {
    String? userId = await StorageServices.getData(
      dataType: StorageKeyConstant.stringType,
      prefKey: StorageKeyConstant.userId,
    );
    String? userName = await StorageServices.getData(
      dataType: StorageKeyConstant.stringType,
      prefKey: StorageKeyConstant.userName,
    );

    if (userId == null || userName == null) {
      // Handle case where user information is not available
      print('User information is missing.');
      return;
    }

    final url = Uri.parse('https://rentswale.com/api/package_recharge.php');

    final Map<String, String> params = {
      'user_id': userId,
      'username': userName,
      'package_id': package.packageId!,
      'package_name': package.packageName!,
      'amount': package.amount.toString(),
      'no_of_post': '2',
      'days': package.days.toString(),
      'transaction_no': '11',
    };

    try {
      final response = await http.post(url, body: params);

      if (response.statusCode == 200) {
        // Show success dialog or perform UI update
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Purchase Success'),
              content: Text('Your package was purchased successfully!'),
              backgroundColor: Colors.greenAccent,
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      } else {
        throw Exception('Failed to purchase package');
      }
    } catch (e) {
      print('Error purchasing package: $e');

      // Show error dialog or handle error
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Purchase Failed'),
            content: Text('Failed to purchase the package. Please try again.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Container(
              alignment: Alignment.topCenter,
              height: Get.height * 0.350,
              width: Get.width,
              decoration: const BoxDecoration(
                color: ColorConstant.redAccent,
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(24),
                  bottomLeft: Radius.circular(24),
                ),
              ),
              child: Padding(
                padding: EdgeInsets.only(top: Get.height * 0.050),
                child: Text(
                  "Choose Your Plan",
                  style: TextStyleConstant.bold30(color: ColorConstant.white),
                ),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(
                top: Get.height * 0.120,
                bottom: Get.height * 0.060,
                left: screenWidthPadding,
                right: screenWidthPadding,
              ),
              child: Container(
                padding: contentPadding,
                height: Get.height,
                width: Get.width,
                decoration: BoxDecoration(
                  color: ColorConstant.lightGrey.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(28),
                ),
                child: Column(
                  children: [
                    Container(
                      height: 400,
                      child: ListView.builder(
                        itemCount: (packageList.length / 2).ceil(),
                        itemBuilder: (context, index) {
                          final int firstIndex = index * 2;
                          final int secondIndex = firstIndex + 1;

                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              buildPlanOption(packageList[firstIndex], index),
                              if (secondIndex < packageList.length)
                                buildPlanOption(packageList[secondIndex], index),
                            ],
                          );
                        },
                      ),
                    ),
                    SizedBox(height: 20),
                    if (selectedPlan != null)
                      Container(
                        padding: EdgeInsets.all(16),
                        color: Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                    Icons.check_circle,
                                    color: ColorConstant.greenTick,
                                    size: 20,
                                  ),
                                  SizedBox(width: 10),
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        getDescription(selectedPlan!),
                                        style: TextStyleConstant.semiBold14(),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              buildPointWithTick('Point 1'),
                              buildPointWithTick('Point 2'),
                              buildPointWithTick('Point 3'),
                            ],
                          ),
                        ),
                      ),
                    SizedBox(height: 50),
                    if (selectedPlan != null)
                      Center(
                        child: CustomButton(
                          title: "Buy Package",
                          onTap: () {
                            final selectedPackage = packageList.firstWhere(
                                  (package) => package.packageName == selectedPlan,
                              orElse: () => PackageList(),
                            );
                            purchasePackage(selectedPackage);
                          },
                        ),
                      ),
                  ],
                ),
              ),

            ),
          ),
        ],
      ),
    );
  }

  Widget buildPlanOption(PackageList package, int index) {
    bool isSelected = selectedPlan == package.packageName!;
    Color bgColor = itemColors[index % itemColors.length];

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedPlan = isSelected ? null : package.packageName!;
        });
      },
      child: Container(
        margin: EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? ColorConstant.redAccent : Colors.transparent,
            width: 2,
          ),
          color: bgColor,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 150, // Set a fixed width for each package option
            padding: EdgeInsets.all(16),
            child: Column(
            //  crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom:4),
                  child: Center(
                    child: Text(
                      package.packageName!,
                      style: TextStyleConstant.semiBold18(),
                    ),
                  ),
                ),
                SizedBox(height: 8),
                Center(
                  child: Text(
                    "${package.amount} ₹ / ${package.days} Days",
                    style: TextStyleConstant.semiBold18(),
                  ),
                ),
                if (isSelected)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 8),
                      Text(
                        getDescription(package.packageName!),
                        style: TextStyleConstant.regular16(),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }


  String getDescription(String planName) {
    // Find the selected package based on its name
    var selectedPackage = packageList.firstWhere(
          (package) => package.packageName == planName,
      orElse: () => PackageList(),
    );

    // Return the description of the selected package
    return selectedPackage.description ?? "Description not available";
  }


  Widget buildPointWithTick(String pointText) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          Icons.check_circle,
          color: ColorConstant.greenTick,
          size: 20,
        ),
        SizedBox(width: 10),
        Expanded(
          child: Text(
            pointText,
            style: TextStyle(fontSize: 16),
          ),
        ),
      ],
    );
  }
}
