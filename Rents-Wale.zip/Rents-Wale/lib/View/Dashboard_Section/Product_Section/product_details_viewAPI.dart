import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';

class NewProductDetails extends StatefulWidget {
  final String itemMasterId;

  const NewProductDetails({Key? key, required this.itemMasterId}) : super(key: key);

  @override
  _NewProductDetailsState createState() => _NewProductDetailsState();
}

class _NewProductDetailsState extends State<NewProductDetails> {
  Map<String, dynamic>? productDetails; // Use Map to hold single product details

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final response = await http.post(
        Uri.parse('https://rentswale.com/api/product_description.php'),
        body: {'item_master_id': widget.itemMasterId},
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        final descriptions = jsonData['product_description'];

        if (descriptions is List && descriptions.isNotEmpty) {
          setState(() {
            productDetails = descriptions.first; // Take the first item from the list
          });
        } else {
          print('Empty or invalid product description list');
        }
      } else {
        print('Failed to load product description: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching data: $e');
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
            // Background Container
            Container(
              alignment: Alignment.topCenter,
              padding: EdgeInsets.only(
                top: Get.height * 0.050,
                left: screenWidthPadding,
                right: screenWidthPadding,
              ),
              height: Get.height * 0.350,
              width: Get.width,
              decoration: BoxDecoration(
                color: ColorConstant.redAccent,
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(24),
                  bottomLeft: Radius.circular(24),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    alignment: Alignment.center,
                    height: Get.height * 0.057,
                    width: Get.width * 0.121,
                    decoration: BoxDecoration(
                      color: ColorConstant.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.menu),
                  ),
                  Image.asset(
                    ImagePathConstant.logo1,
                    height: Get.height * 0.070,
                    width: Get.width * 0.486,
                  ),
                  Container(
                    padding: contentPadding,
                    height: Get.height * 0.057,
                    width: Get.width * 0.300,
                    decoration: BoxDecoration(
                      color: ColorConstant.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Pune",
                          style: TextStyleConstant.semiBold18(
                            color: ColorConstant.darkGrey,
                          ),
                        ),
                        const Icon(Icons.pin_drop, color: ColorConstant.darkGrey),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Main Content
            Positioned.fill(
              top: Get.height * 0.120,
              child: Padding(
                padding: screenPadding,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      alignment: Alignment.center,
                      height: Get.height * 0.350,
                      decoration: BoxDecoration(
                        color: ColorConstant.extraLightGrey,
                        borderRadius: BorderRadius.circular(36),
                      ),
                      child: productDetails == null
                          ? Center(child: CircularProgressIndicator())
                          : CarouselSlider(
                        items: [
                          if (productDetails!['item_img'] != null && productDetails!['item_img'].isNotEmpty)
                            Image.network(
                              'https://rentswale.com/admin/uploads/item/${productDetails!['item_img']}',
                              fit: BoxFit.cover,
                            ),
                          if (productDetails!['item_img_one'] != null &&
                              productDetails!['item_img_one'].isNotEmpty)
                            Image.network(
                              'https://rentswale.com/admin/uploads/item/${productDetails!['item_img_one']}',
                              fit: BoxFit.cover,
                            ),
                          if (productDetails!['item_img_two'] != null &&
                              productDetails!['item_img_two'].isNotEmpty)
                            Image.network(
                              'https://rentswale.com/admin/uploads/item/${productDetails!['item_img_two']}',
                              fit: BoxFit.cover,
                            ),
                          if (productDetails!['item_img_three'] != null &&
                              productDetails!['item_img_three'].isNotEmpty)
                            Image.network(
                              'https://rentswale.com/admin/uploads/item/${productDetails!['item_img_three']}',
                              fit: BoxFit.cover,
                            ),
                        ],
                        options: CarouselOptions(
                          height: 300,
                          enlargeCenterPage: true,
                          autoPlay: true,
                        ),
                      ),
                    ),
                    SizedBox(height: Get.height * 0.020),
                    Text(
                      '${productDetails?['item_name'] ?? ''}',
                      style: TextStyleConstant.semiBold30(),
                    ),
                    SizedBox(height: Get.height * 0.020),
                    Text(
                      '\u20B9 : ${productDetails?['price'] ?? ''}',
                      style: TextStyleConstant.semiBold36(),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Delivery Charge: ${productDetails?['delivery_charge'] ?? ''}',
                      style: TextStyle(fontSize: 16),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Terms & Specifications:',
                      style: TextStyleConstant.semiBold26(),
                    ),
                    Text(
                      productDetails?['term_specification'] ?? '',
                      style: TextStyleConstant.medium18(
                        color: ColorConstant.darkGrey,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            FloatingActionButton(
              onPressed: () {},
              backgroundColor: Colors.red,
              child: const Icon(Icons.message, color: Colors.white),
            ),
            FloatingActionButton(
              onPressed: () {},
              backgroundColor: Colors.red,
              child: const Icon(Icons.call, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
