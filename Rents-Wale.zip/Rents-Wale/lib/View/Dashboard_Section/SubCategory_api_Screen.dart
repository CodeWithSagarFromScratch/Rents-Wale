import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/View/Product_List_view.dart';

class SubcategoryPage extends StatefulWidget {
  final String categoryId;
  final String categoryMasterName;

  SubcategoryPage(this.categoryId, this.categoryMasterName);

  @override
  _SubcategoryPageState createState() => _SubcategoryPageState();
}

class _SubcategoryPageState extends State<SubcategoryPage> {
  List<Map<String, dynamic>> _subcategoryList = [];

  @override
  void initState() {
    super.initState();
    fetchSubcategories();
  }

  Future<void> fetchSubcategories() async {
    // Define the request body
    Map<String, String> body = {'category_id': widget.categoryId};

    final response = await http.post(
      Uri.parse('https://rentswale.com/api/subcategory_list.php'),
      body: body,
    );

    log("Get subcategory response ::: ${response.body}");

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      if (jsonData['status_code'] == '200') {
        setState(() {
          _subcategoryList =
              List<Map<String, dynamic>>.from(jsonData['subcategory_list']);
        });
      } else {
        // Handle error
      }
    } else {
      // Handle network error
    }
  }

  void navigateToProductListScreen(String subcategoryId) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              ProductListScreen(widget.categoryId, subcategoryId)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.categoryMasterName),
      ),
      body: GridView.builder(
        padding: screenPadding,
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          //  crossAxisSpacing: 5,
          mainAxisSpacing: 35,
        ),
        itemCount: _subcategoryList.length,
        itemBuilder: (context, index) {
          final subcategory = _subcategoryList[index];
          return GestureDetector(
            onTap: () {
              navigateToProductListScreen(subcategory['sub_category_id']);
            },
            child: Column(
              //   mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: contentPadding,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      width: 2,
                      color: ColorConstant.redAccent,
                    ),
                  ),
                  child: Image.network(
                    'https://rentswale.com/admin/uploads/subcategory/${subcategory['Image_icon']}',
                    height: Get.height * 0.040,
                  ),
                ),
                SizedBox(height: 10),
                // Text(subcategory['sub_category'], style: TextStyleConstant.semiBold14()),
                Flexible(
                  child: Text(
                    subcategory['sub_category'],
                    style: TextStyleConstant.semiBold14(),
                    textAlign: TextAlign.center, // Adjust alignment as needed
                    overflow:
                        TextOverflow.ellipsis, // Handle overflow gracefully
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
