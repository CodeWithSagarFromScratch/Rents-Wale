import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';

import 'SubCategory_api_Screen.dart';

class CategoryListPage extends StatefulWidget {
  @override
  _CategoryListPageState createState() => _CategoryListPageState();
}

class _CategoryListPageState extends State<CategoryListPage> {
  List<Map<String, dynamic>> _categoryList = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final response = await http.get(Uri.parse('https://rentswale.com/api/category_list.php'));
    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      if (jsonData['status_code'] == '200') {
        setState(() {
          _categoryList = List<Map<String, dynamic>>.from(jsonData['category_list']);
        });
      } else {
        // Handle error
      }
    } else {
      // Handle network error
    }
  }

  void navigateToSubcategoryPage(String categoryId,String categoryMasterName) {
    // Navigate to the SubcategoryPage and pass the category ID
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SubcategoryPage(categoryId,categoryMasterName)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      GridView.builder(
       padding: screenPadding,
      //  shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
           // crossAxisSpacing: 5,
          mainAxisSpacing:30,
        ),
        itemCount: _categoryList.length,
        itemBuilder: (context, index) {
          final category = _categoryList[index];
          return GestureDetector(
            onTap: () {
              navigateToSubcategoryPage(category['category_id'],category['category_master']);
            },
            child: Column(
              children: [
                Container(
                  padding: contentPadding,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      width: 2,
                      color: ColorConstant.redAccent,
                    ),
                  ),
                  child: Image.network(
                    'https://rentswale.com/admin/uploads/icon/${category['icon']}',
                    height: Get.height * 0.035, // Adjust image height as needed
                    fit: BoxFit.contain, // Ensure image fits within the container
                  ),
                ),
                SizedBox(height: 10),
                Flexible(
                  child: Text(
                    category['category_master'],
                    style: TextStyleConstant.semiBold14(),
                    textAlign: TextAlign.center, // Adjust alignment as needed
                    overflow: TextOverflow.ellipsis, // Handle overflow gracefully
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
