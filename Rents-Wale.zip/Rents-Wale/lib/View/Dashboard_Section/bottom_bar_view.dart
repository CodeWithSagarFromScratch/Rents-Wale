import 'package:awesome_bottom_bar/awesome_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Controllers/bottom_bar_controller.dart';

class BottomBarView extends StatelessWidget {
  BottomBarView({super.key});

  BottomBarController controller = Get.put(BottomBarController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        return Center(
          child:
          controller.screenList.elementAt(controller.selectedIndex.value),
        );
      }),
      bottomNavigationBar: Obx(() {
        return BottomBarCreative(
            items: const [
              TabItem(icon: Icons.home_filled),
              TabItem(icon: Icons.chat),
              TabItem(icon: Icons.add),
             TabItem(icon: Icons.photo),
              TabItem(icon: Icons.person),
            ],
            backgroundColor: ColorConstant.white,
            color: ColorConstant.lightGrey,
            colorSelected: ColorConstant.redAccent,
            indexSelected: controller.selectedIndex.value,
            isFloating: true,
            onTap: (int index) {
              controller.selectedIndex.value = index;
            });
      }),
    );
  }
}
