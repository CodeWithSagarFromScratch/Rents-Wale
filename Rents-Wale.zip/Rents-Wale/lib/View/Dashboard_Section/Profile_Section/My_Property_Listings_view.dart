import 'package:flutter/material.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'ActiveScreen_view.dart';
import 'AllDataScreen_view.dart';
import 'DeactiveScreen_view.dart';

class MyProperyListingpage extends StatefulWidget {
  const MyProperyListingpage({super.key});

  @override
  _MyProperyListingpageState createState() => _MyProperyListingpageState();
}

class _MyProperyListingpageState extends State<MyProperyListingpage> {
  final List<String> options = ['Active ', 'Deactive', 'All'];
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    double appBarHeight = kToolbarHeight +
        60; // Default AppBar height + additional height for options and text
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(appBarHeight),
        child: AppBar(
          title: const Text(
            'My Property Listings',
            style: TextStyle(color: Colors.white),
          ),
          iconTheme: const IconThemeData(color: Colors.white),

          backgroundColor: ColorConstant.redAccent,
          //  color: ColorConstant.lightGrey.withOpacity(0.3),
          flexibleSpace: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: kToolbarHeight + 10),
              // Adjust the height as needed

              const SizedBox(height: 10),
              // Adjust the height as needed
              SingleChildScrollView(
                // Wrap the Row in SingleChildScrollView
            //    scrollDirection: Axis.horizontal,
                // Set scroll direction to horizontal
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(
                    options.length,
                    (index) => GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedIndex = index;
                        });
                      },
                      child: Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        color: index == selectedIndex
                            ? Colors.white
                            : Colors.transparent,
                        child: Text(
                          options[index],
                          style: TextStyle(
                            color: index == selectedIndex
                                ? Colors.red
                               //  ? Colors.blue
                                : Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: getContent(selectedIndex),
    );
  }

  Widget getContent(int index) {
    switch (index) {
      case 0:
        //  return ActiveScreen();
        return ActiveScreen();
      case 1:
        return DeactiveScreen();
      // //  return Assignment_page();
      case 2:
        return AllDataScreen();
      default:
        return const SizedBox.shrink();
    }
  }
}

class OptionSlider extends StatelessWidget {
  final List<String> options;
  final int selectedIndex;
  final Function(int) onOptionSelected;

  const OptionSlider({super.key,
    required this.options,
    required this.selectedIndex,
    required this.onOptionSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: options.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              onOptionSelected(index);
            },
            child: Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.symmetric(horizontal: 10),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: index == selectedIndex ? Colors.blue : Colors.grey,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                options[index],
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
