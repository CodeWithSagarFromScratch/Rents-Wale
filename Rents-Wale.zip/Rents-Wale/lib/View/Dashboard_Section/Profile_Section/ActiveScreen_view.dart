import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/plan_view.dart';

class ActiveScreen extends StatefulWidget {
  @override
  _ActiveScreenState createState() => _ActiveScreenState();
}

class _ActiveScreenState extends State<ActiveScreen> {
  List<Map<String, dynamic>> myPostList = [];

  @override
  void initState() {
    super.initState();
    fetchMyPostList();
  }

  Future<void> fetchMyPostList() async {
    try {
      String userId = await StorageServices.getData(
          dataType: StorageKeyConstant.stringType,
          prefKey: StorageKeyConstant.userId);
      final url = Uri.parse('https://rentswale.com/api/my_post_list_all.php');
      final params = {'user_id': userId};
      final response = await http.post(url, body: params);

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData['status_code'] == '200' &&
            responseData['status'] == 'success') {
          setState(() {
            myPostList =
            List<Map<String, dynamic>>.from(responseData['my_post_list']);
          });
        } else {
          print('API request failed: ${responseData['message']}');
        }
      } else {
        print('Failed to connect to API: Status Code ${response.statusCode}');
      }
    } catch (error) {
      print('Error fetching data: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        itemCount: myPostList.length,
        itemBuilder: (context, index) {
          final post = myPostList[index];
          final itemImages = [
            post['item_img'],
            post['item_img_one'],
            post['item_img_two'],
            post['item_img_three'],
          ].where((img) => img != null).toList();

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      post['item_name'],
                      style: TextStyle(
                        fontSize:18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    //SizedBox(height: 5),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Price/Month: ${post['price_month']}',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                post['city_name'] ?? 'City not specified',
                                style: TextStyle(
                               fontSize:18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 35), // Adjusted spacing
                              ElevatedButton(
                                onPressed: () {
                                  // Handle edit button pressed
                                },
                                style: ButtonStyle(
                                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4), // Adjust the border radius
                                      side: BorderSide(color: Colors.black),
                                    ),
                                  ),
                                  backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
                                  minimumSize: MaterialStateProperty.all<Size>(Size(10,20)), // Adjust button size
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.only(top:10,bottom: 5), // Adjust padding
                                  child: Text(
                                    'Edit',
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(width:5), // Adjusted spacing
                        Stack(
                          children: [
                            InkWell(
                              onTap: () {
                                // Handle upload media pressed
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 50),
                                decoration: BoxDecoration(
                                  color: Colors.grey[300],
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.camera_alt),
                                    SizedBox(width: 5),
                                    Text('Upload Media'),
                                  ],
                                ),
                              ),
                            ),
                            if (itemImages.isNotEmpty)
                              Positioned.fill(
                                child: Image.network(
                                  'https://rentswale.com/admin/uploads/item/${itemImages.first}',
                                  fit: BoxFit.cover,
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(height:5), // Adjusted spacing
                    Divider(
                      color: Colors.black,
                      height: 5,
                      thickness: 2,
                    ),
                    SizedBox(height:5), // Adjusted spacing
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            post['address'] ?? 'City not specified',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        SizedBox(width:10),
                        Container(
                          height: 35,
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child:
                          TextButton(
                            onPressed: () {
                              // Handle go premium button pressed
                              Navigator.push(context, MaterialPageRoute(builder: (context) => PlanView()));
                            },
                            child: Row(
                              children: [
                                Icon(Icons.star, color: Colors.white, size:18), // Icon before text
                                Text(
                                  'Go Premium',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}


