import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/kyc_controller.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/bottom_bar_view.dart';
import 'package:rent_wale_latest/Widgets/custom_button.dart';
import 'package:rent_wale_latest/Widgets/custom_textfield.dart';


class AboutsUsView extends StatelessWidget {
  const AboutsUsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<KycController>(
          init: KycController(),
          builder: (controller) {
            return Stack(
              children: [
                Container(
                  alignment: Alignment.topCenter,
                  height: Get.height * 0.400,
                  width: Get.width,
                  decoration: const BoxDecoration(
                      color: ColorConstant.redAccent,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(24),
                          bottomLeft: Radius.circular(24))),
                  child: Padding(
                    padding: EdgeInsets.only(top: Get.height * 0.050),
                    child: Text(
                      "About US",
                      style:
                      TextStyleConstant.bold30(color: ColorConstant.white),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: Get.height * 0.120,
                        bottom: Get.height * 0.060,
                        left: screenWidthPadding,
                        right: screenWidthPadding),
                    child: Container(
                      padding: screenPadding,
                      height: Get.height,
                      width: Get.width,
                      decoration: BoxDecoration(
                          color: ColorConstant.lightGrey.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(28)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Image.asset(
                              ImagePathConstant.logo1,
                              height: Get.height * 0.080,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: Get.height * 0.060,
                                bottom: Get.height * 0.006),
                            child: Text("Rentswale was established in 2020 and is headquartered in Pune."
                                " We engaged in provide good quality various products"
                                " to our valuable customer by online service. We offer "
                                "to come people together, shop together, earn together and grow together",
                              style: TextStyleConstant.semiBold16(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          }),
    );
  }
}
