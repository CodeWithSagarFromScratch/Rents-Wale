import 'dart:convert';
import 'package:http/http.dart' as http;

Future<void> postPackageRecharge() async {
  String apiUrl = 'https://rentswale.com/api/package_recharge.php';

  String userId = '86';
  String username = '7972890968';
  String packageId = '6';
  String packageName = 'Basic Plan';
  String amount = '399';
  String noOfPost = '2';
  String days = '30';
  String transactionNo = '11';

  Map<String, String> requestBody = {
    'user_id': userId,
    'username': username,
    'package_id': packageId,
    'package_name': packageName,
    'amount': amount,
    'no_of_post': noOfPost,
    'days': days,
    'transaction_no': transactionNo,
  };

  try {
    var response = await http.post(Uri.parse(apiUrl), body: requestBody);

    if (response.statusCode == 200) {
      var responseBody = jsonDecode(response.body);
      String statusCode = responseBody['status_code'];
      String status = responseBody['status'];

      if (statusCode == '200' && status == 'success') {
        var packagePurchaseResult = responseBody['package_purchase_result'];
        String id = packagePurchaseResult['id'];
        String userId = packagePurchaseResult['user_id'];
        String username = packagePurchaseResult['username'];
        String packageId = packagePurchaseResult['package_id'];
        String packageName = packagePurchaseResult['package_name'];
        String totalNoOfPost = packagePurchaseResult['tot_no_of_post'];
        String rechargeDate = packagePurchaseResult['recharge_dt'];
        String expiryDate = packagePurchaseResult['expirydate'];
        String transactionNo = packagePurchaseResult['transaction_no'];

        // Handle successful response here
        print('Package recharge successful!');
        print('Package ID: $id');
        print('User ID: $userId');
        print('Username: $username');
        print('Package Name: $packageName');
        print('Total Number of Posts: $totalNoOfPost');
        print('Recharge Date: $rechargeDate');
        print('Expiry Date: $expiryDate');
        print('Transaction No: $transactionNo');
      } else {
        // Handle API response error
        print('Package recharge failed: $status');
      }
    } else {
      // Handle HTTP request failure
      print('Failed to post package recharge: ${response.statusCode}');
    }
  } catch (error) {
    // Handle other errors
    print('Error posting package recharge: $error');
  }
}
