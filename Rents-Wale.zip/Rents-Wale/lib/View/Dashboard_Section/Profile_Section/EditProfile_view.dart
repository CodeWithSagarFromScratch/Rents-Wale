import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/edit_profile_controller.dart';
import 'package:rent_wale_latest/Services/form_validation_services.dart';
import 'package:rent_wale_latest/Widgets/custom_button.dart';
import 'package:rent_wale_latest/Widgets/custom_textfield.dart';

class EditProfileView extends StatefulWidget {
  const EditProfileView({super.key});

  @override
  State<EditProfileView> createState() => _EditProfileViewState();
}

class _EditProfileViewState extends State<EditProfileView> {
  EditProfileController controller = Get.put(EditProfileController());

  @override
  void initState() {
    super.initState();
    controller.initialFunctioun().whenComplete(() => setState(() {}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Container(
            alignment: Alignment.topCenter,
            height: Get.height * 0.350,
            width: Get.width,
            decoration: const BoxDecoration(
              color: ColorConstant.redAccent,
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(24),
                bottomLeft: Radius.circular(24),
              ),
            ),
            child: Padding(
              padding: EdgeInsets.only(top: Get.height * 0.050),
              child: Text(
                "Edit Your Account",
                style: TextStyleConstant.bold30(color: ColorConstant.white),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: EdgeInsets.only(
                top: Get.height * 0.120,
                bottom: Get.height * 0.060,
                left: screenWidthPadding,
                right: screenWidthPadding,
              ),
              child: Container(
                padding: screenPadding,
                height: Get.height,
                width: Get.width,
                decoration: BoxDecoration(
                  color: ColorConstant.lightGrey.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(28),
                ),
                child: Form(
                  key: controller.formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Image.asset(
                          ImagePathConstant.logo,
                          height: Get.height * 0.080,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: Get.height * 0.040,
                          bottom: Get.height * 0.006,
                        ),
                        child: Text(
                          "Edit Name",
                          style: TextStyleConstant.semiBold16(),
                        ),
                      ),
                      CustomTextField(
                        controller: controller.nameController,
                        hintText: "Name",
                        textInputType: TextInputType.name,
                        prefixIcon: const Icon(Icons.person),
                        validator: FormValidationServices.validateField(
                            fieldName: "Name"),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: Get.height * 0.020,
                          bottom: Get.height * 0.006,
                        ),
                        child: Text(
                          "Edit Email",
                          style: TextStyleConstant.semiBold16(),
                        ),
                      ),
                      CustomTextField(
                        controller: controller.emailController,
                        hintText: "Email",
                        textInputType: TextInputType.emailAddress,
                        prefixIcon: const Icon(Icons.email),
                        validator: FormValidationServices.validateEmail(),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: Get.height * 0.020,
                          bottom: Get.height * 0.006,
                        ),
                        child: Text(
                          "Edit Address",
                          style: TextStyleConstant.semiBold16(),
                        ),
                      ),
                      CustomTextField(
                        controller: controller.addressController,
                        hintText: "Address",
                        textInputType: TextInputType.streetAddress,
                        prefixIcon: const Icon(Icons.location_city),
                        validator: FormValidationServices.validateField(
                            fieldName: "Address"),
                      ),
                      const Spacer(),
                      Align(
                        alignment: Alignment.center,
                        child: CustomButton(
                          title: "Edit Profile",
                          onTap: () {
                            if (controller.formKey.currentState!.validate()) {
                              controller.postEditProfile();
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
