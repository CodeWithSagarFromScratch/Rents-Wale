import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/color_constant.dart';
import 'package:rent_wale_latest/Constant/image_path_constant.dart';
import 'package:rent_wale_latest/Constant/layout_constant.dart';
import 'package:rent_wale_latest/Constant/textstyle_constant.dart';
import 'package:rent_wale_latest/Controllers/kyc_controller.dart';
import 'package:rent_wale_latest/Widgets/custom_textfield.dart';



class ContactUsView extends StatelessWidget {
  const ContactUsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<KycController>(
          init: KycController(),
          builder: (controller) {
            return Stack(
              children: [
                Container(
                  alignment: Alignment.topCenter,
                  height: Get.height * 0.450,
                  width: Get.width,
                  decoration: const BoxDecoration(
                      color: ColorConstant.redAccent,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(24),
                          bottomLeft: Radius.circular(24))),
                  child: Padding(
                    padding: EdgeInsets.only(top: Get.height * 0.050),
                    child: Text(
                      "Contact Us",
                      style:
                      TextStyleConstant.bold30(color: ColorConstant.white),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: Get.height * 0.120,
                        bottom: Get.height * 0.060,
                        left: screenWidthPadding,
                        right: screenWidthPadding),
                    child: Container(
                      padding: screenPadding,
                      height: Get.height,
                      width: Get.width,
                      decoration: BoxDecoration(
                          color: ColorConstant.lightGrey.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(28)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                            alignment: Alignment.center,
                            child: Image.asset(
                              ImagePathConstant.logo1,
                              height: Get.height * 0.080,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: Get.height * 0.060,
                                bottom: Get.height * 0.006),
                            child: Text(
                              "Contact Number :(+918530066744)",
                              style: TextStyleConstant.semiBold16(),
                            ),
                          ),
                          // CustomTextField(
                          //   controller: controller.adharController,
                          //   hintText: "Adhar Number",
                          //   textInputType: TextInputType.text,
                          //   prefixIcon: const Icon(Icons.person),
                          // ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: Get.height * 0.020,
                                bottom: Get.height * 0.006),
                            child: Text(
                              "Email : info@rentswale.com",
                              style: TextStyleConstant.semiBold16(),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                top: Get.height * 0.020,
                                bottom: Get.height * 0.006),
                            child: Text(
                              "Address :108-Yash101 sus Behind Mercedes-Benz off Mumbai pune highway Baner,Pune.",
                              style: TextStyleConstant.semiBold16(),

                            ),
                          ),


                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          }),
    );
  }
}
