import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:latlong2/latlong.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/enter_address_view.dart';

class LocationPickerView extends StatefulWidget {
  final String itemId;

  const LocationPickerView({super.key, required this.itemId});

  @override
  State<LocationPickerView> createState() => _LocationPickerViewState();
}

class _LocationPickerViewState extends State<LocationPickerView> {
  final MapController _mapController = MapController();
  LatLng _selectedLocation = const LatLng(0.0, 0.0);
  bool _pinDropped = false;
  String address = "";
  String pinCode = "";
  String state = "";
  String city = "";
  String subLocality = "";
  String mapboxAccessToken =
      'sk.eyJ1IjoianJmbHV0dGVyZGV2IiwiYSI6ImNsbTdvZGVnbjAzNHgzY2xtcDdvNnpwbmgifQ.N8wHhuOEvcCMNroZ0P3o2g';
  late PermissionStatus permissionStatus;

  @override
  void initState() {
    super.initState();
    checkPermissionStatus();
  }

  Future<void> checkPermissionStatus() async {
    final status = await Permission.location.status;
    setState(() {
      permissionStatus = status;
    });

    if (permissionStatus.isGranted) {
      getCurrentLocation().whenComplete(() => setState(() {}));
    } else {
      requestPermission();
    }
  }

  Future<void> requestPermission() async {
    final status = await Permission.location.request();
    setState(() {
      permissionStatus = status;
    });
  }

  Future<void> getCurrentLocation() async {
    try {
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      log("Current location ::: $position");
      _selectedLocation = LatLng(position.latitude, position.longitude);
      _pinDropped = true;
      _mapController.move(_selectedLocation, 15.0);
      List<Placemark> placeMarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      log(">>>>>>>>>>>> ${placeMarks[0]}");

      pinCode = "${placeMarks[0].postalCode}";
      state = "${placeMarks[0].administrativeArea}";
      city = "${placeMarks[0].locality}";
      address = "${placeMarks[0].street}";
      subLocality = "${placeMarks[0].subLocality}";
    } catch (error) {
      log("Something went wrong during getting current location ::: $error");
    }
  }

  void handleMapTap(LatLng tappedLocation) async {
    _selectedLocation = tappedLocation;
    _pinDropped = true;
    _mapController.move(_selectedLocation, _mapController.zoom);

    List<Placemark> placeMarks = await placemarkFromCoordinates(
      tappedLocation.latitude,
      tappedLocation.longitude,
    );
    log(">>>>>>>>>>>> ${placeMarks[0]}");

    pinCode = "${placeMarks[0].postalCode}";
    state = "${placeMarks[0].administrativeArea}";
    city = "${placeMarks[0].locality}";
    address = "${placeMarks[0].street}";
    subLocality = "${placeMarks[0].subLocality}";

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pick Your Location'),
      ),
      body: Column(
        children: [
          Expanded(
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                zoom: 15.0,
                maxZoom: 22.0,
                onTap: (tapPosition, latLng) {
                  handleMapTap(latLng);
                },
              ),
              children: [
                TileLayer(
                  urlTemplate:
                      "https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/{z}/{x}/{y}?access_token=$mapboxAccessToken",
                  additionalOptions: {
                    'accessToken': mapboxAccessToken,
                    'id': 'mapbox.mapbox-streets-v11',
                  },
                ),
                MarkerLayer(
                  markers: [
                    if (_pinDropped)
                      Marker(
                        width: 40,
                        height: 40,
                        point: _selectedLocation,
                        child: SvgPicture.network(
                          'https://upload.wikimedia.org/wikipedia/commons/d/d1/Google_Maps_pin.svg',
                          width: 40,
                          height: 40,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Current Address: $address"),
              const SizedBox(height: 5),
            ],
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16),
        child: ElevatedButton(
          onPressed: getCurrentLocation,
          child: const Text('Get My Location'),
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () async {
            Get.to(() => EnterAddressView(
                itemId: widget.itemId,
                address: address,
                pinCode: pinCode,
                state: state,
                city: city,
                subLocality: subLocality));
          },
          elevation: 0,
          child: const Icon(Icons.check)), // Remove the button's shadow
    );
  }
}
