import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Models/post_signup_model.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/View/bottom_bar_view.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';
import 'package:rent_wale_latest/Widgets/custom_toast.dart';


class SignupController extends GetxController {
  PostSignupModel postSignupModel = PostSignupModel();

  TextEditingController phoneController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController selectTypeController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  Future postSignup() async {
    try {
      CustomLoader.openCustomLoader();

      Map<String, dynamic> payload = {
        "username": phoneController.text,
        "name": nameController.text,
        "email_address": emailController.text,
        "type": selectTypeController.text,
        "password": passwordController.text
      };

      log("Post sign up payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.register, payload: payload);

      postSignupModel = postSignupModelFromJson(response["body"]);

      if (postSignupModel.statusCode == "200" ||
          postSignupModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();

        await StorageServices.setData(
            dataType: StorageKeyConstant.boolType,
            prefKey: StorageKeyConstant.isAuthenticate,
            boolData: true);
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.name,
            stringData: "${postSignupModel.result?.name}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userName,
            stringData: "${postSignupModel.result?.username}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.email,
            stringData: "${postSignupModel.result?.emailAddress}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userType,
            stringData: "${postSignupModel.result?.type}");

        Get.offAll(() => BottomBarView());
       // Get.offAll(() => CategoryListScreen());
      } else {
        CustomLoader.closeCustomLoader();
        customToast(message: "${postSignupModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during sign up ::: $error");
    }
  }
}
