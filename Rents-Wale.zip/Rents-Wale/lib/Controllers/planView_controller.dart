import 'dart:convert';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Models/planView_model.dart';
import 'package:rent_wale_latest/Models/slider_images_model.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';


class PlanViewController extends GetxController  {
  GetPlanViewModel getPlanViewModel = GetPlanViewModel();
  String? selectedPlan;


  @override
  void onInit() {
    super.onInit();
    getPlanViewList();

  }


  Future getPlanViewList() async {
    try {
      CustomLoader.openCustomLoader();
      // Map<String, String> payload = {"type": "Type1"};

      var response =
      await HttpServices.getHttpMethod(url: EndPointConstant.packagelist);

      debugPrint("Get packagelist response ::: $response");

      getPlanViewModel = GetPlanViewModelFromJson(response["body"]);

      if (getPlanViewModel.statusCode == "200" ||
          getPlanViewModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        update();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting banner images ::: ${getPlanViewModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting banner images ::: $error");
    }
  }


}
