import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class KycController extends GetxController{
  TextEditingController adharController = TextEditingController();
  TextEditingController diController = TextEditingController();
}