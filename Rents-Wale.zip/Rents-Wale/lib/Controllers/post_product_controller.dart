import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Models/get_category_model.dart';
import 'package:rent_wale_latest/Models/get_sub_category_model.dart';
import 'package:rent_wale_latest/Models/post_product_category_model.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/enter_address_view.dart';
import 'package:rent_wale_latest/View/location_picker_view.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';

class PostProductController extends GetxController {
  GetCategoryListModel getCategoryListModel = GetCategoryListModel();
  GetSubCategoryModel getSubCategoryModel = GetSubCategoryModel();
  PostProductCategoryModel postProductCategoryModel =
      PostProductCategoryModel();

  TextEditingController priceController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  RxList tenureList = ["Per Day", "Per Month"].obs;
  RxString selectedCategory = "Select Category".obs;
  RxString selectedCategoryId = "".obs;
  RxString selectedSubCategory = "Select Subcategory".obs;
  RxString selectedSubCategoryId = "".obs;
  RxString selectedTenure = "Select Tenure".obs;

  final formKey = GlobalKey<FormState>();

  Future getCategoryList() async {
    try {
      CustomLoader.openCustomLoader();

      var response =
          await HttpServices.getHttpMethod(url: EndPointConstant.categoryList);

      debugPrint("Get category list response ::: $response");

      getCategoryListModel = getCategoryListModelFromJson(response["body"]);

      if (getCategoryListModel.statusCode == "200" ||
          getCategoryListModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting category list ::: ${getCategoryListModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting category list ::: $error");
    }
  }

  Future getSubCategoryList() async {
    try {
      CustomLoader.openCustomLoader();

      Map<String, dynamic> payload = {"category_id": selectedCategoryId.value};

      log("Get sub category list payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.subCategoryList, payload: payload);

      debugPrint("Get sub category list response ::: $response");

      getSubCategoryModel = getSubCategoryModelFromJson(response["body"]);

      if (getSubCategoryModel.statusCode == "200" ||
          getSubCategoryModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting sub category list ::: ${getSubCategoryModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting sub category list ::: $error");
    }
  }

  Future postProductCategory() async {
    try {
      CustomLoader.openCustomLoader();

      String userId = await StorageServices.getData(
          dataType: StorageKeyConstant.stringType,
          prefKey: StorageKeyConstant.userId);

      Map<String, dynamic> payload = {
        "user_id": userId,
        "category_id": selectedCategoryId.value,
        "sub_category_id": selectedSubCategoryId.value,
        "item_name": nameController.text,
        "tenure": selectedTenure.value,
        "price": priceController.text,
        "description": descriptionController.text,
      };

      log("Post product category payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.addPostPage1, payload: payload);

      log("Post product category response ::: $response");

      postProductCategoryModel =
          postProductCategoryModelFromJson(response["body"]);

      if (postProductCategoryModel.statusCode == "200" ||
          postProductCategoryModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        Get.to(() => LocationPickerView(
            itemId: "${postProductCategoryModel.itemAddResult?.itemId}"));
        // Get.to(() => EnterAddressView(
        //     itemId: "${postProductCategoryModel.itemAddResult?.itemId}"));
      } else {
        CustomLoader.closeCustomLoader();
        log("Something went wrong during posting product ::: ${postProductCategoryModel.status}");
      }
    } catch (error, st) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during posting product ::: $error");
      log("Something went wrong during posting product ::: $st");
    }
  }
}
