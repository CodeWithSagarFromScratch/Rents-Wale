import 'package:get/get.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/ads_view.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/chat_view.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/dashboard_view.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/post_product_view.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/profile_view.dart';

class BottomBarController extends GetxController {
  RxList screenList = [
    const DashboardView(),
    const ChatView(),
    const PostProductView(),
    const AdsView(),
    const ProfileView(),
  ].obs;
  RxInt selectedIndex = 0.obs;
}
