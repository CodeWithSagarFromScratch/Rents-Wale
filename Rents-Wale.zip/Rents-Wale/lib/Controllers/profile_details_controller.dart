import 'dart:developer';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Models/profile_deailes_model.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';

class ProfileController extends GetxController {
  GetProfileDetailmodel getProfileDetailmodel = GetProfileDetailmodel();

  @override
  void onInit() {
    super.onInit();
    fetchProfile();
  }

  Future<void> fetchProfile() async {
    try {
      CustomLoader.openCustomLoader();

      String username = await StorageServices.getData(
          dataType: StorageKeyConstant.stringType,
          prefKey: StorageKeyConstant.userName);

      Map<String, String> payload = {"username": username};
      final response = await HttpServices.postHttpMethod(
        url: EndPointConstant.profile,
        payload: payload,
      );

      log("Get profile detail response ::: $response");

      // Parse the response body and update the model
      getProfileDetailmodel = getProfileDetailmodelFromJson(response["body"]);

      if (getProfileDetailmodel.statusCode == "200" ||
          getProfileDetailmodel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
      } else {
        CustomLoader.closeCustomLoader();
        log("Something went wrong during profile data fetching ::: ${getProfileDetailmodel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      log("Error fetching profile data: $error");
    }
    update();
  }
}
