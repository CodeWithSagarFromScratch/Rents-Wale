import 'dart:developer';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:image_picker/image_picker.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Models/post_address_model.dart';
import 'package:rent_wale_latest/View/Dashboard_Section/plan_view.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';
import 'package:http/http.dart' as http;
import 'package:rent_wale_latest/Widgets/custom_toast.dart';

class EnterAddressController extends GetxController {
  PostAddressModel postAddressModel = PostAddressModel();

  TextEditingController locationController = TextEditingController();
  TextEditingController pinCodeController = TextEditingController();
  TextEditingController cityNameController = TextEditingController();
  TextEditingController localityNameController = TextEditingController();
  TextEditingController stateController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  File? selectedImage1;
  File? selectedImage2;
  File? selectedImage3;
  File? selectedImage4;

  Future<void> pickImage(
      {required int imageNo, required ImageSource imageSource}) async {
    final pickedImage = await ImagePicker().pickImage(source: imageSource);

    if (pickedImage?.path != null) {
      if (imageNo == 1) {
        selectedImage1 = File(pickedImage!.path);
      } else if (imageNo == 2) {
        selectedImage2 = File(pickedImage!.path);
      } else if (imageNo == 3) {
        selectedImage3 = File(pickedImage!.path);
      } else if (imageNo == 4) {
        selectedImage4 = File(pickedImage!.path);
      }
    } else {
      log("No image selected");
    }
  }

  Future postAddress({required String itemId}) async {
    CustomLoader.openCustomLoader();
    try {
      var header = {
        'Content-type': 'application/json',
        'Accept': 'application/json'
      };

      log("Item id ::: $itemId");
      log("State ::: ${stateController.text}");
      log("City ::: ${cityNameController.text}");
      log("Locality ::: ${localityNameController.text}");
      log("Pin code ::: ${pinCodeController.text}");
      log("Address ::: ${localityNameController.text}");
      log("Image 1 ::: ${selectedImage1?.path}");
      log("Image 2 ::: ${selectedImage2?.path}");
      log("Image 3 ::: ${selectedImage3?.path}");
      log("Image 4 ::: ${selectedImage4?.path}");

      var request = http.MultipartRequest(
          'POST',
          Uri.parse(
              "${EndPointConstant.baseUrl}${EndPointConstant.addPostProductForm2}"));

      request.headers.addAll(header);

      request.fields['item_id'] = itemId;
      request.fields['state'] = stateController.text;
      request.fields['city_name'] = cityNameController.text;
      request.fields['locality'] = localityNameController.text;
      request.fields['pincode'] = pinCodeController.text;
      request.fields['address'] = localityNameController.text;

      request.files.add(await http.MultipartFile.fromPath(
          "image1", "${selectedImage1?.path}"));
      request.files.add(await http.MultipartFile.fromPath(
          "image2", "${selectedImage2?.path}"));
      request.files.add(await http.MultipartFile.fromPath(
          "image3", "${selectedImage3?.path}"));
      request.files.add(await http.MultipartFile.fromPath(
          "image4", "${selectedImage4?.path}"));

      var response = await request.send();
      var responsed = await http.Response.fromStream(response);

      log("Post address response ::: ${responsed.body}");

      postAddressModel = postAddressModelFromJson(responsed.body);

      if (postAddressModel.statusCode == "200" ||
          postAddressModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        customToast(message: "${postAddressModel.message}");
        Get.to(() => const PlanView());
      } else {
        CustomLoader.closeCustomLoader();
        customToast(message: "${postAddressModel.message}");
      }
    } catch (error, st) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during posting address ::: $error");
      log("Error location during posting address ::: $st");
    }
  }
}
