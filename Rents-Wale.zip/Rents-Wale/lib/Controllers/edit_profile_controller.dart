import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Models/get_profile_model.dart';
import 'package:rent_wale_latest/Models/post_edit_profile_model.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';
import 'package:rent_wale_latest/Widgets/custom_toast.dart';

class EditProfileController extends GetxController {
  GetProfileModel getProfileModel = GetProfileModel();
  PostEditProfileModel postEditProfileModel = PostEditProfileModel();

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController addressController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  RxString userName = "".obs;

  Future initialFunctioun() async {
    userName.value = await StorageServices.getData(
        dataType: StorageKeyConstant.stringType,
        prefKey: StorageKeyConstant.userName);

    await getProfile();
  }

  Future getProfile() async {
    try {
      CustomLoader.openCustomLoader();

      Map<String, dynamic> payload = {"username": userName.value};

      log("Get profile payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.profile, payload: payload);

      log("Get profile response ::: $response");

      getProfileModel = getProfileModelFromJson(response["body"]);

      if (getProfileModel.statusCode == "200" ||
          getProfileModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        nameController.text = getProfileModel.profileList?[0].name ?? "";
        emailController.text =
            getProfileModel.profileList?[0].emailAddress ?? "";
        addressController.text = getProfileModel.profileList?[0].address ?? "";
      } else {
        CustomLoader.closeCustomLoader();
        log("Something went wrong during getting profile :: ${getProfileModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint("Something went wrong during getting profile ::: $error");
    }
  }

  Future postEditProfile() async {
    try {
      CustomLoader.openCustomLoader();

      Map<String, dynamic> payload = {
        "username": userName.value,
        "name": nameController.text,
        "email_address": emailController.text,
        "address": addressController.text,
        "flat_details": "",
        "landmark": "",
        "direction": "",
        "profile_image": "",
      };

      log("Post edit profile payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.updateprofile, payload: payload);

      log("Post update profile response ::: $response");

      postEditProfileModel = postEditProfileModelFromJson(response["body"]);

      if (postEditProfileModel.statusCode == "200" ||
          postEditProfileModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        customToast(message: "Profile has been updated");
        Get.back();
      } else {
        CustomLoader.closeCustomLoader();
        customToast(message: "${postEditProfileModel.statusCode}");
      }
    } catch (error, st) {
      CustomLoader.closeCustomLoader();
      debugPrint("Something went wrong during posting edit profile ::: $error");
      debugPrint("Something went wrong during posting edit profile ::: $st");
    }
  }
}
