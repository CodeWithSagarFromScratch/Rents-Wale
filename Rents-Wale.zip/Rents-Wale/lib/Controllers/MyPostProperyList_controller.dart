import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Models/MyPostPropertyList_model.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';

class MyPostPropertyListController extends GetxController {
  GetMyPostPropertListModel getMyPostPropertListModel =
      GetMyPostPropertListModel();

  final formKey = GlobalKey<FormState>();

  @override
  void onInit() {
    super.onInit();
    postMyPropertyList();
  }

  Future postMyPropertyList() async {
    try {
      CustomLoader.openCustomLoader();

      String userId = await StorageServices.getData(
          dataType: StorageKeyConstant.stringType,
          prefKey: StorageKeyConstant.userId);

      Map<String, dynamic> payload = {
        "user_id": userId,
      };

      log("Post product category payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.mypostlistall, payload: payload);

      log("Post product category response ::: $response");

      getMyPostPropertListModel =
          getMyPostPropertListModelFromJson(response["body"]);

      if (getMyPostPropertListModel.statusCode == "200" ||
          getMyPostPropertListModel.status == "success") {
        CustomLoader.closeCustomLoader();
        // Get.to(() => EnterAddressView(
        //   itemId: "${postProductCategoryModel.itemAddResult?.itemId}",
        // )
        // );
      } else {
        CustomLoader.closeCustomLoader();
        log("Something went wrong during posting product ::: ${getMyPostPropertListModel.status}");
      }
    } catch (error, st) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during posting product ::: $error");
      log("Something went wrong during posting product ::: $st");
    }
  }
}
