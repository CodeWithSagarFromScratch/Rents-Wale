import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Models/post_login_model.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/View/bottom_bar_view.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';
import 'package:rent_wale_latest/Widgets/custom_toast.dart';

class LoginController extends GetxController {
  PostLoginModel postLoginModel = PostLoginModel();

  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  Future<void> postLogin() async {
    try {
      CustomLoader.openCustomLoader();

      Map<String, dynamic> payload = {
        "username": phoneController.text,
        "password": passwordController.text,
      };

      log("Post login payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.login, payload: payload);

      postLoginModel = postLoginModelFromJson(response["body"]);

      if (postLoginModel.statusCode == "200" ||
          postLoginModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        log('Login successful. Navigating to BottomBarView...');
        await StorageServices.setData(
            dataType: StorageKeyConstant.boolType,
            prefKey: StorageKeyConstant.isAuthenticate,
            boolData: true);
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.name,
            stringData: "${postLoginModel.result?.name}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userId,
            stringData: "${postLoginModel.result?.id}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userName,
            stringData: "${postLoginModel.result?.username}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.email,
            stringData: "${postLoginModel.result?.emailAddress}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userType,
            stringData: "${postLoginModel.result?.type}");

        customToast(message: "${postLoginModel.message}");
        Get.offAll(() => BottomBarView());
      } else {
        CustomLoader.closeCustomLoader();
        customToast(message: "${postLoginModel.message}");
        Get.offAll(() => BottomBarView());
        //  Get.offAll(() => CategoryListPage());
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during login ::: $error");
    }
  }
}
