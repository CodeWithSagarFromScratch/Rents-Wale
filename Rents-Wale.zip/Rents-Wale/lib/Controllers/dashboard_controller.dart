import 'package:get/get.dart';
import 'package:flutter/cupertino.dart';
import 'package:rent_wale_latest/Widgets/custom_loader.dart';
import 'package:rent_wale_latest/Services/http_services.dart';
import 'package:rent_wale_latest/Models/get_category_model.dart';
import 'package:rent_wale_latest/Models/slider_images_model.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/Models/ChooseLocation_model.dart';
import 'package:rent_wale_latest/Models/get_offerImages_model.dart';

class DashboardController extends GetxController {
  GetBannerImagesModel getBannerImagesModel = GetBannerImagesModel();
  GetCategoryListModel getCategoryListModel = GetCategoryListModel();
  ChooeseLocationmodel getChooeseLocationModel = ChooeseLocationmodel();
  GetOfferImagesModel getOfferImagesModel = GetOfferImagesModel();

  // GetBranchListModel getBranchListModel = GetBranchListModel();

  @override
  void onInit() {
    super.onInit();
    getBannerImages();
    getCategoryList();
    getLocationList();
    getOfferImages();
  }

  Future getBannerImages() async {
    try {
      CustomLoader.openCustomLoader();
      // Map<String, String> payload = {"type": "Type1"};

      var response =
          await HttpServices.getHttpMethod(url: EndPointConstant.slider);

      debugPrint("Get banner images response ::: $response");

      getBannerImagesModel = getBannerImagesModelFromJson(response["body"]);

      if (getBannerImagesModel.statusCode == "200" ||
          getBannerImagesModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        update();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting banner images ::: ${getBannerImagesModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting banner images ::: $error");
    }
  }

  Future getCategoryList() async {
    try {
      CustomLoader.openCustomLoader();

      var response =
          await HttpServices.getHttpMethod(url: EndPointConstant.categoryList);

      debugPrint("Get category list response ::: $response");

      getCategoryListModel = getCategoryListModelFromJson(response["body"]);

      if (getCategoryListModel.statusCode == "200" ||
          getCategoryListModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        update();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting category list ::: ${getCategoryListModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting category list ::: $error");
    }
  }

  Future getLocationList() async {
    try {
      CustomLoader.openCustomLoader();

      var response =
          await HttpServices.getHttpMethod(url: EndPointConstant.citylist);

      debugPrint("Get location list response ::: $response");

      getChooeseLocationModel =
          getChooseLocationWiswModelFromJson(response["body"]);

      if (getChooeseLocationModel.statusCode == "200" ||
          getChooeseLocationModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        update();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting location list ::: ${getChooeseLocationModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting location list ::: $error");
    }
  }

  Future getOfferImages() async {
    try {
      CustomLoader.openCustomLoader();
      // Map<String, String> payload = {"type": "Type1"};

      var response =
          await HttpServices.getHttpMethod(url: EndPointConstant.OfferImages);

      debugPrint("Get banner images response ::: $response");

      getOfferImagesModel = getOfferImagesModelFromJson(response["body"]);

      if (getOfferImagesModel.statusCode == "200" ||
          getOfferImagesModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        update();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting banner images ::: ${getOfferImagesModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting banner images ::: $error");
    }
  }
}
