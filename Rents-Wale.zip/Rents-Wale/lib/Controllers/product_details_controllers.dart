import 'dart:developer';

import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/endpoint_constant.dart';
import 'package:rent_wale_latest/models/product_details_description_model.dart';
import 'package:rent_wale_latest/services/http_services.dart';
import 'package:rent_wale_latest/widgets/custom_loader.dart';

class ProductDetailsController extends GetxController {
  late GetProductDescriptionModel getProductDescriptionModel;

  @override
  void onInit() {
    super.onInit();
    // Initialize the product description model
    getProductDescriptionModel = GetProductDescriptionModel();
  }

  Future<void> getProductDetailDescription(String itemMasterId) async {
    try {
      CustomLoader.openCustomLoader();

      final payload = {"item_master_id": itemMasterId};
      final response = await HttpServices.postHttpMethod(url: EndPointConstant.productdescription, payload: payload);

      log("Get product description response ::: $response");

      if (response != null && (response['status_code'] == "200" || response['status_code'] == "201")) {
        // Parse the response into the product description model
        getProductDescriptionModel = GetProductDescriptionModel.fromJson(response);
        CustomLoader.closeCustomLoader();
        update(); // Update the controller to reflect changes in the model
      } else {
        CustomLoader.closeCustomLoader();
        log("Failed to get product description: ${response['message']}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      log("Error getting product description: $error");
    }
  }
}
