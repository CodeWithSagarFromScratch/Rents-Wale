import 'package:get/get.dart';
import 'package:rent_wale_latest/Constant/storage_key_constant.dart';
import 'package:rent_wale_latest/Services/storage_services.dart';
import 'package:rent_wale_latest/View/Authentication_Section/login_view.dart';
import 'package:rent_wale_latest/View/bottom_bar_view.dart';

class SplashController extends GetxController {
  RxBool isAuthenticate = false.obs;

  @override
  void onInit() {
    super.onInit();
    navigateScreen();
  }

  navigateScreen() async {
    isAuthenticate.value = await StorageServices.getData(
            dataType: StorageKeyConstant.boolType,
            prefKey: StorageKeyConstant.isAuthenticate) ??
        false;
    Future.delayed(
      const Duration(seconds: 3),
      () {
        if (isAuthenticate.value) {
          Get.offAll(() => BottomBarView());
        } else {
          Get.offAll(const LoginView());
        }
      },
    );
  }
}
