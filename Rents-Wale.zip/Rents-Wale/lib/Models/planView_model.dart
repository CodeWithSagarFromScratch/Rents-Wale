import 'dart:convert';

GetPlanViewModel GetPlanViewModelFromJson(String str) =>
    GetPlanViewModel.fromJson(json.decode(str));

String getPlanViewModelToJson(GetPlanViewModel data) =>
    json.encode(data.toJson());

class GetPlanViewModel {
  String? statusCode;
  String? message;
  List<PackageList>? packagelist;

  GetPlanViewModel({
    this.statusCode,
    this.message,
    this.packagelist,
  });

  factory GetPlanViewModel.fromJson(Map<String, dynamic> json) =>
      GetPlanViewModel(
        statusCode: json["status_code"],
        message: json["message"],
        packagelist: List<PackageList>.from(
            json["package_list"].map((x) => PackageList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "status_code": statusCode,
        "message": message,
        "package_list": (packagelist != null)
            ? List<dynamic>.from(packagelist!.map((x) => x.toJson()))
            : null,
      };
}

class PackageList {
  String? packageId;
  String? packageName;
  String? description;
  String? amount;
  String? noOfPost;
  String? days;

  PackageList(
      {this.packageId,
      this.packageName,
      this.description,
      this.amount,
      this.noOfPost,
      this.days});

  factory PackageList.fromJson(Map<String, dynamic> json) => PackageList(
        packageId: json["package_id"],
        packageName: json["package_name"],
        description: json["description"],
        amount: json["amount"],
        noOfPost: json["no_of_post"],
        days: json["days"],
      );

  Map<String, dynamic> toJson() => {
        "package_id": packageId,
        "package_name": packageName,
        'description': description,
        'amount': amount,
        'no_of_post': noOfPost,
        'days': days


      };
}
