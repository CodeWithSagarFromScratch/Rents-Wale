import 'dart:convert';

GetCategoryListModel getCategoryListModelFromJson(String str) => GetCategoryListModel.fromJson(json.decode(str));

String getCategoryListModelToJson(GetCategoryListModel data) => json.encode(data.toJson());

class GetCategoryListModel {
  String? statusCode;
  String? message;
  List<CategoryList>? categoryList;

  GetCategoryListModel({this.statusCode, this.message, this.categoryList});

  factory GetCategoryListModel.fromJson(Map<String, dynamic> json) {
    return GetCategoryListModel(
      statusCode: json['status_code'],
      message: json['message'],
      categoryList: List<CategoryList>.from(json['category_list'].map((x) => CategoryList.fromJson(x))),
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status_code'] = statusCode;
    data['message'] = message;
    if (categoryList != null) {
      data['category_list'] = categoryList!.map((x) => x.toJson()).toList();
    }
    return data;
  }
}

class CategoryList {
  String? categoryId;
  String? categoryMaster;
  String? icon;

  CategoryList({this.categoryId, this.categoryMaster, this.icon});

  factory CategoryList.fromJson(Map<String, dynamic> json) {
    return CategoryList(
      categoryId: json['category_id'],
      categoryMaster: json['category_master'],
      icon: "https://rentswale.com/admin/uploads/${json["icon"]}",
    );
  }
  Map<String, dynamic> toJson() => {
    "id": categoryId,
    "category_name": categoryMaster,
    "category_image": icon,
  };
}
