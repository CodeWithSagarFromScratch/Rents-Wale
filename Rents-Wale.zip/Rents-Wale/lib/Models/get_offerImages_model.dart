import 'dart:convert';

GetOfferImagesModel getOfferImagesModelFromJson(String str) =>
    GetOfferImagesModel.fromJson(json.decode(str));

String getOfferImagesModelToJson(GetOfferImagesModel data) =>
    json.encode(data.toJson());

class GetOfferImagesModel {
  String? statusCode;
  String? message;
  List<OffererListImages>? offerlist;

  GetOfferImagesModel({
    this.statusCode,
    this.message,
    this.offerlist,
  });

  factory GetOfferImagesModel.fromJson(Map<String, dynamic> json) =>
      GetOfferImagesModel(
        statusCode: json["status_code"],
        message: json["message"],
        offerlist: List<OffererListImages>.from(
            json["offer_list"].map((x) => OffererListImages.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "status_code": statusCode,
    "message": message,
    "offer_list": (offerlist != null)
        ? List<dynamic>.from(offerlist!.map((x) => x.toJson()))
        : null,
  };
}

class OffererListImages {
  String? id;
  String? sliderimage;

  OffererListImages({
    this.id,
    this.sliderimage,
  });

  factory OffererListImages.fromJson(Map<String, dynamic> json) => OffererListImages(
    id: json["offer_list"],
    // Prepend the base URL to the slider image
    sliderimage: "https://rentswale.com/admin/uploads/item/${json["slider_image"]}",
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "slider_image": sliderimage,
  };
}

