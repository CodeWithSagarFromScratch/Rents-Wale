import 'dart:convert';

PostProductCategoryModel postProductCategoryModelFromJson(String str) =>
    PostProductCategoryModel.fromJson(json.decode(str));

String postProductCategoryModelToJson(PostProductCategoryModel data) =>
    json.encode(data.toJson());

class PostProductCategoryModel {
  String? statusCode;
  String? status;
  ItemAddResult? itemAddResult;

  PostProductCategoryModel({
    this.statusCode,
    this.status,
    this.itemAddResult,
  });

  factory PostProductCategoryModel.fromJson(Map<String, dynamic> json) =>
      PostProductCategoryModel(
        statusCode: json["status_code"],
        status: json["status"],
        itemAddResult: ItemAddResult.fromJson(json["item_add_result"]),
      );

  Map<String, dynamic> toJson() => {
        "status_code": statusCode,
        "status": status,
        "item_add_result": itemAddResult?.toJson(),
      };
}

class ItemAddResult {
  String? itemId;
  String? categoryId;
  String? subCategoryId;
  String? itemName;
  String? tenure;
  String? price;
  String? priceMonth;
  String? description;
  String? userId;

  ItemAddResult({
    this.itemId,
    this.categoryId,
    this.subCategoryId,
    this.itemName,
    this.tenure,
    this.price,
    this.priceMonth,
    this.description,
    this.userId,
  });

  factory ItemAddResult.fromJson(Map<String, dynamic> json) => ItemAddResult(
        itemId: json["item_id"],
        categoryId: json["category_id"],
        subCategoryId: json["sub_category_id"],
        itemName: json["item_name"],
        tenure: json["tenure"],
        price: json["price"],
        priceMonth: json["price_month"],
        description: json["description"],
        userId: json["user_id"],
      );

  Map<String, dynamic> toJson() => {
        "item_id": itemId,
        "category_id": categoryId,
        "sub_category_id": subCategoryId,
        "item_name": itemName,
        "tenure": tenure,
        "price": price,
        "price_month": priceMonth,
        "description": description,
        "user_id": userId,
      };
}
