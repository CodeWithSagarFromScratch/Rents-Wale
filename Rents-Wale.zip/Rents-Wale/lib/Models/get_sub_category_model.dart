import 'dart:convert';

GetSubCategoryModel getSubCategoryModelFromJson(String str) =>
    GetSubCategoryModel.fromJson(json.decode(str));

String getSubCategoryModelToJson(GetSubCategoryModel data) =>
    json.encode(data.toJson());

class GetSubCategoryModel {
  String? statusCode;
  String? message;
  List<SubcategoryList>? subcategoryList;

  GetSubCategoryModel({
    this.statusCode,
    this.message,
    this.subcategoryList,
  });

  factory GetSubCategoryModel.fromJson(Map<String, dynamic> json) =>
      GetSubCategoryModel(
        statusCode: json["status_code"],
        message: json["message"],
        subcategoryList: List<SubcategoryList>.from(
            json["subcategory_list"].map((x) => SubcategoryList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "status_code": statusCode,
        "message": message,
        "subcategory_list":
            List<dynamic>.from(subcategoryList!.map((x) => x.toJson())),
      };
}

class SubcategoryList {
  String? subCategoryId;
  String? categoryId;
  String? subCategory;
  String? imageIcon;

  SubcategoryList({
    this.subCategoryId,
    this.categoryId,
    this.subCategory,
    this.imageIcon,
  });

  factory SubcategoryList.fromJson(Map<String, dynamic> json) =>
      SubcategoryList(
        subCategoryId: json["sub_category_id"],
        categoryId: json["category_id"],
        subCategory: json["sub_category"],
        imageIcon: json["Image_icon"],
      );

  Map<String, dynamic> toJson() => {
        "sub_category_id": subCategoryId,
        "category_id": categoryId,
        "sub_category": subCategory,
        "Image_icon": imageIcon,
      };
}
