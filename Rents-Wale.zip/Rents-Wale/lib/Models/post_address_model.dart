import 'dart:convert';

PostAddressModel postAddressModelFromJson(String str) =>
    PostAddressModel.fromJson(json.decode(str));

String postAddressModelToJson(PostAddressModel data) =>
    json.encode(data.toJson());

class PostAddressModel {
  String? statusCode;
  String? status;
  String? message;
  PostUpdatePage2Result? postUpdatePage2Result;

  PostAddressModel({
    this.statusCode,
    this.status,
    this.message,
    this.postUpdatePage2Result,
  });

  factory PostAddressModel.fromJson(Map<String, dynamic> json) =>
      PostAddressModel(
        statusCode: json["status_code"],
        status: json["status"],
        message: json["message"],
        postUpdatePage2Result: (json["post_update_page2_result"] != null)
            ? PostUpdatePage2Result.fromJson(json["post_update_page2_result"])
            : null,
      );

  Map<String, dynamic> toJson() => {
        "status_code": statusCode,
        "status": status,
        "message": message,
        "post_update_page2_result": (postUpdatePage2Result != null)
            ? postUpdatePage2Result?.toJson()
            : null,
      };
}

class PostUpdatePage2Result {
  String? itemId;
  String? state;
  String? cityName;
  String? categoryId;
  String? subCategoryId;
  String? itemName;
  String? tenure;
  String? price;
  String? priceMonth;
  String? userId;
  String? itemImg;
  String? itemImgOne;
  String? itemImgTwo;
  String? itemImgThree;
  String? address;
  String? pincode;
  String? locality;
  String? position;

  PostUpdatePage2Result({
    this.itemId,
    this.state,
    this.cityName,
    this.categoryId,
    this.subCategoryId,
    this.itemName,
    this.tenure,
    this.price,
    this.priceMonth,
    this.userId,
    this.itemImg,
    this.itemImgOne,
    this.itemImgTwo,
    this.itemImgThree,
    this.address,
    this.pincode,
    this.locality,
    this.position,
  });

  factory PostUpdatePage2Result.fromJson(Map<String, dynamic> json) =>
      PostUpdatePage2Result(
        itemId: json["item_id"],
        state: json["state"],
        cityName: json["city_name"],
        categoryId: json["category_id"],
        subCategoryId: json["sub_category_id"],
        itemName: json["item_name"],
        tenure: json["tenure"],
        price: json["price"],
        priceMonth: json["price_month"],
        userId: json["user_id"],
        itemImg: json["item_img"],
        itemImgOne: json["item_img_one"],
        itemImgTwo: json["item_img_two"],
        itemImgThree: json["item_img_three"],
        address: json["address"],
        pincode: json["pincode"],
        locality: json["locality"],
        position: json["position"],
      );

  Map<String, dynamic> toJson() => {
        "item_id": itemId,
        "state": state,
        "city_name": cityName,
        "category_id": categoryId,
        "sub_category_id": subCategoryId,
        "item_name": itemName,
        "tenure": tenure,
        "price": price,
        "price_month": priceMonth,
        "user_id": userId,
        "item_img": itemImg,
        "item_img_one": itemImgOne,
        "item_img_two": itemImgTwo,
        "item_img_three": itemImgThree,
        "address": address,
        "pincode": pincode,
        "locality": locality,
        "position": position,
      };
}
