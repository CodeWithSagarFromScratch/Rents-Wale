import 'dart:convert';

ChooeseLocationmodel getChooseLocationWiswModelFromJson(String str) =>
    ChooeseLocationmodel.fromJson(json.decode(str));

String getchooeseLocationmodelToJson(ChooeseLocationmodel data) =>
    json.encode(data.toJson());

class ChooeseLocationmodel {
  String? statusCode;
  String? message;
  List<CityList>? cityList;

  ChooeseLocationmodel({
    this.statusCode,
    this.message,
    this.cityList,
  });

  factory ChooeseLocationmodel.fromJson(Map<String, dynamic> json) =>
      ChooeseLocationmodel(
        statusCode: json["status_code"],
        message: json["message"],
        cityList: List<CityList>.from(
            json["city_list"].map((x) => CityList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "status_code": statusCode,
    "message": message,
    "city_list": cityList != null
        ? List<dynamic>.from(cityList!.map((x) => x.toJson()))
        : null,
  };
}

class CityList {
  String? id;
  String? name;

  CityList({
    this.id,
    this.name,
  });

  factory CityList.fromJson(Map<String, dynamic> json) => CityList(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}
