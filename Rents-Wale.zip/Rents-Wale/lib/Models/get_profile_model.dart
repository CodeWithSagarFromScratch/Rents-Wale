import 'dart:convert';

GetProfileModel getProfileModelFromJson(String str) =>
    GetProfileModel.fromJson(json.decode(str));

String getProfileModelToJson(GetProfileModel data) =>
    json.encode(data.toJson());

class GetProfileModel {
  String? statusCode;
  String? message;
  List<ProfileList>? profileList;

  GetProfileModel({
    this.statusCode,
    this.message,
    this.profileList,
  });

  factory GetProfileModel.fromJson(Map<String, dynamic> json) =>
      GetProfileModel(
        statusCode: json["status_code"],
        message: json["message"],
        profileList: (json["profile_list"] != null)
            ? List<ProfileList>.from(
                json["profile_list"].map((x) => ProfileList.fromJson(x)))
            : null,
      );

  Map<String, dynamic> toJson() => {
        "status_code": statusCode,
        "message": message,
        "profile_list": (profileList != null)
            ? List<dynamic>.from(profileList!.map((x) => x.toJson()))
            : null,
      };
}

class ProfileList {
  String? id;
  String? name;
  String? emailAddress;
  String? address;
  dynamic? profileImage;
  dynamic? flatDetails;
  dynamic? landmark;
  dynamic? direction;

  ProfileList({
    this.id,
    this.name,
    this.emailAddress,
    this.address,
    this.profileImage,
    this.flatDetails,
    this.landmark,
    this.direction,
  });

  factory ProfileList.fromJson(Map<String, dynamic> json) => ProfileList(
        id: json["id"],
        name: json["name"],
        emailAddress: json["email_address"],
        address: json["address"],
        profileImage: json["profile_image"],
        flatDetails: json["flat_details"],
        landmark: json["landmark"],
        direction: json["direction"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "email_address": emailAddress,
        "address": address,
        "profile_image": profileImage,
        "flat_details": flatDetails,
        "landmark": landmark,
        "direction": direction,
      };
}
