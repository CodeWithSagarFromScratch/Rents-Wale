import 'dart:convert';

PostEditProfileModel postEditProfileModelFromJson(String str) =>
    PostEditProfileModel.fromJson(json.decode(str));

String postEditProfileModelToJson(PostEditProfileModel data) =>
    json.encode(data.toJson());

class PostEditProfileModel {
  String? statusCode;
  Result? result;

  PostEditProfileModel({
    this.statusCode,
    this.result,
  });

  factory PostEditProfileModel.fromJson(Map<String, dynamic> json) =>
      PostEditProfileModel(
        statusCode: json["Status_code"],
        result:
            (json["result"] != null) ? Result.fromJson(json["result"]) : null,
      );

  Map<String, dynamic> toJson() => {
        "Status_code": statusCode,
        "result": (result != null) ? result?.toJson() : null,
      };
}

class Result {
  String? id;
  String? name;
  String? emailAddress;
  String? address;
  String? profileImage;
  String? flatDetails;
  String? landmark;
  String? direction;

  Result({
    this.id,
    this.name,
    this.emailAddress,
    this.address,
    this.profileImage,
    this.flatDetails,
    this.landmark,
    this.direction,
  });

  factory Result.fromJson(Map<String, dynamic> json) => Result(
        id: json["id"],
        name: json["name"],
        emailAddress: json["email_address"],
        address: json["address"],
        profileImage: json["profile_image"],
        flatDetails: json["flat_details"],
        landmark: json["landmark"],
        direction: json["direction"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "email_address": emailAddress,
        "address": address,
        "profile_image": profileImage,
        "flat_details": flatDetails,
        "landmark": landmark,
        "direction": direction,
      };
}
