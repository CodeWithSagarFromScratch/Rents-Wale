import 'dart:convert';

GetMyPostPropertListModel getMyPostPropertListModelFromJson(String str) =>
    GetMyPostPropertListModel.fromJson(json.decode(str));

String getMyPostPropertListModelToJson(GetMyPostPropertListModel data) =>
    json.encode(data.toJson());

class GetMyPostPropertListModel {
  String? statusCode;
  String? status;
  String? message;
  List<MyPostList>? mypostlist;

  GetMyPostPropertListModel({
    this.statusCode,
    this.status,
    this.message,
    this.mypostlist,
  });

  factory GetMyPostPropertListModel.fromJson(Map<String, dynamic> json) =>
      GetMyPostPropertListModel(
        statusCode: json["status_code"],
        status: json["status"],
        message: json["message"],
        mypostlist: List<MyPostList>.from(
            json["my_post_list"].map((x) => MyPostList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "status_code": statusCode,
    "status": status,
    "message": message,
    "my_post_list": (mypostlist != null)
        ? List<dynamic>.from(mypostlist!.map((x) => x.toJson()))
        : null,
  };
}


class MyPostList {
  String? itemId;
  String? cityName;
  String? categoryId;
  String? subCategoryId;
  String? itemName;
  String? tenure;
  String? price;
  String? priceMonth;
  String? itemImg; // Updated to hold full image URL
  String? itemImgOne;
  String? itemImgTwo;
  String? itemImgThree;
  String? state;
  String? address;
  String? pincode;
  String? locality;
  String? position;
  String? userId;

  MyPostList({
    this.itemId,
    this.cityName,
    this.categoryId,
    this.subCategoryId,
    this.itemName,
    this.tenure,
    this.price,
    this.priceMonth,
    this.itemImg,
    this.itemImgOne,
    this.itemImgTwo,
    this.itemImgThree,
    this.state,
    this.address,
    this.pincode,
    this.locality,
    this.position,
    this.userId,
  });

  // factory MyPostList.fromJson(Map<String, dynamic> json) {
  //   return MyPostList(
        factory MyPostList.fromJson(Map<String, dynamic> json) => MyPostList(
      itemId: json["item_id"],
      cityName: json['city_name'],
      categoryId: json['category_id'],
      subCategoryId: json['sub_category_id'],
      itemName: json['item_name'],
      tenure: json['tenure'],
      price: json['price'],
      priceMonth: json['price_month'],
      itemImg: json['item_img'] != null
          ? 'https://rentswale.com/admin/uploads/item/${json['item_img']}'
          : null, // Construct full image URL
      itemImgOne: json['item_img_one'],
      itemImgTwo: json['item_img_two'],
      itemImgThree: json['item_img_three'],
      state: json['state'],
      address: json['address'],
      pincode: json['pincode'],
      locality: json['locality'],
      position: json['position'],
      userId: json['user_id'],
    );




  Map<String, dynamic> toJson()=> {

      'item_id': itemId,
      'city_name': cityName,
      'category_id': categoryId,
      'sub_category_id': subCategoryId,
      'item_name': itemName,
      'tenure': tenure,
      'price': price,
      'price_month': priceMonth,
      'item_img': itemImg,
      'item_img_one': itemImgOne,
      'item_img_two': itemImgTwo,
      'item_img_three': itemImgThree,
      'state': state,
      'address': address,
      'pincode': pincode,
      'locality': locality,
      'position': position,
      'user_id': userId,
    };
  }

