class GetProductDescriptionModel {
  String? statusCode;
  String? message;
  List<ProductDescription>? productDescription;

  GetProductDescriptionModel({this.statusCode, this.message, this.productDescription});

  factory GetProductDescriptionModel.fromJson(Map<String, dynamic> json) {
    return GetProductDescriptionModel(
      statusCode: json['status_code'],
      message: json['message'],
      productDescription: json['product_description'] != null
          ? List<ProductDescription>.from(json['product_description'].map((x) => ProductDescription.fromJson(x)))
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {
      'status_code': statusCode,
      'message': message,
    };
    if (productDescription != null) {
      data['product_description'] = productDescription!.map((x) => x.toJson()).toList();
    }
    return data;
  }
}

class ProductDescription {
  String? itemMasterId;
  String? cityName;
  String? subCategoryId;
  String? itemName;
  String? price;
  String? priceMonth;
  String? priceThree;
  String? priceSix;
  String? priceNine;
  String? priceTwel;
  String? description;
  String? deposit;
  String? deliveryCharge;
  String? itemImg;
  String? itemImgOne;
  String? itemImgTwo;
  String? itemImgThree;
  String? termSpecification;
  String? userId;
  String? pincode;
  String? address;
  String? locality;
  String? position;

  ProductDescription({
    this.itemMasterId,
    this.cityName,
    this.subCategoryId,
    this.itemName,
    this.price,
    this.priceMonth,
    this.priceThree,
    this.priceSix,
    this.priceNine,
    this.priceTwel,
    this.description,
    this.deposit,
    this.deliveryCharge,
    this.itemImg,
    this.itemImgOne,
    this.itemImgTwo,
    this.itemImgThree,
    this.termSpecification,
    this.userId,
    this.pincode,
    this.address,
    this.locality,
    this.position,
  });

  factory ProductDescription.fromJson(Map<String, dynamic> json) {
    return ProductDescription(
      itemMasterId: json['item_master_id'],
      cityName: json['city_name'],
      subCategoryId: json['sub_category_id'],
      itemName: json['item_name'],
      price: json['price'],
      priceMonth: json['price_month'],
      priceThree: json['price_three'],
      priceSix: json['price_six'],
      priceNine: json['price_nine'],
      priceTwel: json['price_twel'],
      description: json['description'],
      deposit: json['deposite'],
      deliveryCharge: json['delivery_charge'],
      itemImg: 'https://rentswale.com/admin/uploads/item/${json['item_img']}',
      itemImgOne: 'https://rentswale.com/admin/uploads/item/${json['item_img_one']}',
      itemImgTwo: 'https://rentswale.com/admin/uploads/item/${json['item_img_two']}',
      itemImgThree: 'https://rentswale.com/admin/uploads/item/${json['item_img_three']}',
      termSpecification: json['term_specification'],
      userId: json['user_id'] ?? '',
      pincode: json['pincode'] ?? '',
      address: json['address'] ?? '',
      locality: json['locality'] ?? '',
      position: json['position'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "item_master_id": itemMasterId,
      "city_name": cityName,
      "sub_category_id": subCategoryId,
      "item_name": itemName,
      "price": price,
      "price_month": priceMonth,
      "price_three": priceThree,
      "price_six": priceSix,
      "price_nine": priceNine,
      "price_twel": priceTwel,
      "description": description,
      "deposite": deposit,
      "delivery_charge": deliveryCharge,
      "item_img": itemImg,
      "item_img_one": itemImgOne,
      "item_img_two": itemImgTwo,
      "item_img_three": itemImgThree,
      "term_specification": termSpecification,
      "user_id": userId,
      "pincode": pincode,
      "address": address,
      "locality": locality,
      "position": position,
    };
  }
}
