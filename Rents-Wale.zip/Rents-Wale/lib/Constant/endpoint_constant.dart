class EndPointConstant {
  static String baseUrl = "https://rentswale.com/api/";

  static String login = "login.php";
  static String register = "register.php";
  static String citylist = "city_list.php";
  static String categoryList = "category_list.php";
  static String subCategoryList = "subcategory_list.php";
  static String slider = "slider.php";
  static String OfferImages = "offer.php";
  static String productdescription = "product_description.php";
  static String profile = "profile.php";
  static String updateprofile = "update_profile.php";
  static String addPostPage1 = "add_post_page1.php";
  static String addPostProductForm2 = "add_post_product_form2.php";
  static String packagelist = "package_list.php";
  static String mypostlistall = "my_post_list_all.php";
}
