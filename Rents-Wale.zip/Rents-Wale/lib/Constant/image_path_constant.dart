class ImagePathConstant {
  static const String background = "assets/Images/background.png";
  static const String calendar = "assets/Images/calendar.png";
  static const String car = "assets/Images/car.png";
  static const String costume = "assets/Images/costume.png";
  static const String electronics = "assets/Images/electronics.png";
  static const String furniture = "assets/Images/furniture.png";
  static const String hotel = "assets/Images/hotel.png";
  static const String kitchen = "assets/Images/kitchen.png";
  static const String more = "assets/Images/more.png";
  static const String plumber = "assets/Images/plumber.png";
  static const String realState = "assets/Images/real_state.png";
  static const String logo = "assets/Images/logo.png";
  static const String logo1 = "assets/Images/logo1.png";
}
