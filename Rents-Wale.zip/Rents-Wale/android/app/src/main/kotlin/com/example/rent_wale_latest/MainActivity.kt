package com.example.rent_wale_latest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
